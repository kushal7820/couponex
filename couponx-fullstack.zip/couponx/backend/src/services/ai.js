const axios   = require('axios');
const logger  = require('../utils/logger');

const API_URL = 'https://api.anthropic.com/v1/messages';
const MODEL   = 'claude-sonnet-4-6';

const call = async (payload) => {
  const { data } = await axios.post(API_URL, { model: MODEL, max_tokens: 600, ...payload }, {
    headers: {
      'x-api-key': process.env.ANTHROPIC_API_KEY,
      'anthropic-version': '2023-06-01',
      'Content-Type': 'application/json'
    },
    timeout: 20000
  });
  return data.content[0].text.trim();
};

/* ── Coupon AI Scoring ─────────────────────────────────────── */
const scoreCoupon = async ({ brand, category, description, faceValue, salePrice, minOrder, expiryDate }) => {
  const daysLeft  = Math.ceil((new Date(expiryDate) - Date.now()) / 86400000);
  const savingPct = Math.round(((faceValue - salePrice) / faceValue) * 100);

  const prompt = `You are a coupon fraud detection and valuation AI for an Indian marketplace.
Analyze this coupon and respond ONLY with valid JSON — no markdown, no extra text.

Brand: ${brand}
Category: ${category}
Description: ${description}
Face Value: ₹${faceValue}
Sale Price: ₹${salePrice}
Savings: ${savingPct}%
Min Order: ₹${minOrder || 0}
Days Left: ${daysLeft}

JSON schema:
{
  "score": <0-100 integer>,
  "rating": "<hot|good|weak>",
  "fraudRisk": "<low|medium|high>",
  "flags": [<string reasons if any>],
  "recommendation": "<one sentence>",
  "analysis": "<2-3 sentences>",
  "suggestedPrice": <fair integer price in INR>
}`;

  try {
    const text   = await call({ messages: [{ role: 'user', content: prompt }] });
    const clean  = text.replace(/```json|```/g, '').trim();
    return JSON.parse(clean);
  } catch (err) {
    logger.warn('AI scoring fallback used', { err: err.message });
    return fallbackScore(daysLeft, savingPct, minOrder, faceValue);
  }
};

const fallbackScore = (daysLeft, savingPct, minOrder, faceValue) => {
  let score = 50;
  if (savingPct > 70) score += 25; else if (savingPct > 50) score += 15; else if (savingPct > 30) score += 8;
  if (daysLeft > 30) score += 15; else if (daysLeft > 14) score += 8; else if (daysLeft < 5) score -= 15;
  if (!minOrder) score += 10; else if (minOrder < faceValue * 2) score += 5;
  score = Math.min(100, Math.max(0, score));
  return {
    score, rating: score >= 75 ? 'hot' : score >= 55 ? 'good' : 'weak',
    fraudRisk: 'low', flags: [], recommendation: 'Auto-scored (AI unavailable).',
    analysis: `${savingPct}% savings with ${daysLeft} days remaining.`,
    suggestedPrice: Math.round(faceValue * 0.4)
  };
};

/* ── Customer Support Chatbot ──────────────────────────────── */
const SYSTEM = `You are CouponX Support — a helpful, concise, friendly support agent.

PLATFORM FACTS:
• CouponX is a peer-to-peer coupon marketplace in India
• Buyers purchase verified coupons at discounted prices; sellers monetise unused coupons
• All transactions use escrow: buyer pays → money held → coupon validated → OTP sent → buyer enters OTP → code revealed → seller paid
• Coupon codes are AES-256 encrypted and NEVER shown until OTP verification succeeds
• If coupon validation fails or too many wrong OTPs: payment is AUTOMATICALLY refunded (3-5 business days)
• Platform fee: 5% (charged to seller)
• OTP expires in 10 minutes, max 3 attempts

RULES:
• Be concise and helpful
• If you cannot resolve an account/technical issue, say "I'll escalate this — expect a reply within 2 hours"
• Never reveal internal implementation details`;

const chat = async ({ message, history = [], userCtx = null }) => {
  const messages = [
    ...history.slice(-12).map(m => ({ role: m.role, content: m.content })),
    { role: 'user', content: message }
  ];

  const extra = userCtx ? `\n\nUser context: name=${userCtx.name}, role=${userCtx.role}` : '';

  try {
    const reply = await call({ system: SYSTEM + extra, messages });
    return { role: 'assistant', content: reply };
  } catch (err) {
    logger.error('Chatbot error', { err: err.message });
    return { role: 'assistant', content: "I'm having trouble right now. For urgent help, email support@couponx.in 🙏" };
  }
};

module.exports = { scoreCoupon, chat };
