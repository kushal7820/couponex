import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, useAuth } from './context/AuthContext';
import Navbar      from './components/Navbar';
import ChatWidget  from './components/ChatWidget';
import Home        from './pages/Home';
import Login       from './pages/Login';
import Register    from './pages/Register';
import Marketplace from './pages/Marketplace';
import SellCoupon  from './pages/SellCoupon';
import Dashboard   from './pages/Dashboard';
import Payment     from './pages/Payment';

const Guard = ({ children, roles }) => {
  const { user, loading } = useAuth();
  if (loading) return <div className="ls"><div className="spin"/></div>;
  if (!user)   return <Navigate to="/login" replace/>;
  if (roles && !roles.includes(user.role)) return <Navigate to="/" replace/>;
  return children;
};

function Inner() {
  return (
    <BrowserRouter>
      <Navbar/>
      <Routes>
        <Route path="/"           element={<Home/>}/>
        <Route path="/login"      element={<Login/>}/>
        <Route path="/register"   element={<Register/>}/>
        <Route path="/marketplace"element={<Marketplace/>}/>
        <Route path="/sell"       element={<Guard roles={['seller','admin']}><SellCoupon/></Guard>}/>
        <Route path="/dashboard"  element={<Guard><Dashboard/></Guard>}/>
        <Route path="/payment/*"  element={<Guard roles={['buyer','admin']}><Payment/></Guard>}/>
        <Route path="*"           element={<Navigate to="/" replace/>}/>
      </Routes>
      <ChatWidget/>
      <Toaster position="bottom-right" toastOptions={{
        style:{ background:'var(--sur)',color:'var(--txt)',border:'1px solid var(--bdr)' },
        success:{ iconTheme:{ primary:'var(--acc)',secondary:'#000' } }
      }}/>
    </BrowserRouter>
  );
}

export default function App() {
  return <AuthProvider><Inner/></AuthProvider>;
}
