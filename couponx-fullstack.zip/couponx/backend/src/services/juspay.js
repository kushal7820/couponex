/**
 * JusPay Payment Gateway Integration
 * Docs: https://developer.juspay.in/docs
 * Sandbox: https://sandbox.juspay.in
 *
 * Free sandbox account: https://dashboard.juspay.in/register
 */
const axios = require('axios');
const logger = require('../utils/logger');

const BASE   = process.env.JUSPAY_BASE_URL || 'https://sandbox.juspay.in';
const MID    = process.env.JUSPAY_MERCHANT_ID || 'sandbox_merchant';
const APIKEY = process.env.JUSPAY_API_KEY    || 'sandbox_key';

const auth = () => `Basic ${Buffer.from(`${APIKEY}:`).toString('base64')}`;
const headers = () => ({
  Authorization: auth(),
  'Content-Type': 'application/json',
  'x-merchantid': MID,
  version: '2023-12-01'
});

/**
 * Create a JusPay hosted payment session.
 * Returns a paymentUrl the buyer opens to complete payment.
 */
const createSession = async ({ orderId, amount, customerId, email, phone, returnUrl, description }) => {
  try {
    const payload = {
      merchant_id: MID,
      order_id: orderId,
      amount: Number(amount).toFixed(2),
      customer_id: customerId,
      customer_email: email,
      customer_phone: phone || '9999999999',
      payment_page_client_id: MID,
      action: 'paymentPage',
      return_url: returnUrl,
      description: description || 'CouponX Purchase',
      currency: 'INR'
    };

    const { data } = await axios.post(`${BASE}/session`, payload, { headers: headers(), timeout: 12000 });

    logger.info('JusPay session created', { orderId, amount });
    return {
      ok: true,
      paymentUrl: data.payment_links?.web || `${BASE}/merchant/pay/${data.id}`,
      sessionId: data.id,
      orderId: data.order_id
    };
  } catch (err) {
    logger.error('JusPay createSession failed', { orderId, error: err.response?.data || err.message });
    throw new Error(err.response?.data?.error_message || 'Payment session creation failed');
  }
};

/**
 * Fetch order status from JusPay.
 */
const getOrderStatus = async (orderId) => {
  try {
    const { data } = await axios.get(`${BASE}/orders/${orderId}`, { headers: headers(), timeout: 10000 });
    return {
      ok: true,
      orderId: data.order_id,
      status: data.status,         // CHARGED | PENDING | FAILED | COD_INITIATED
      amount: data.amount,
      txnId: data.txn_id,
      method: data.payment_method,
      raw: data
    };
  } catch (err) {
    logger.error('JusPay getOrderStatus failed', { orderId, error: err.message });
    throw new Error('Failed to fetch payment status');
  }
};

/**
 * Initiate a refund via JusPay.
 * Called automatically when coupon validation fails.
 */
const refund = async ({ orderId, amount, refundId, reason }) => {
  try {
    const payload = {
      unique_request_id: refundId,
      amount: Number(amount).toFixed(2),
      order_id: orderId
    };

    const { data } = await axios.post(`${BASE}/orders/${orderId}/refunds`, payload, {
      headers: headers(), timeout: 12000
    });

    logger.info('JusPay refund initiated', { orderId, refundId, amount });
    return { ok: true, refundId: data.id, status: data.status, raw: data };
  } catch (err) {
    logger.error('JusPay refund failed', { orderId, error: err.response?.data || err.message });
    throw new Error(err.response?.data?.error_message || 'Refund initiation failed');
  }
};

/**
 * Map JusPay status strings to our internal payment status.
 */
const mapStatus = (s) => ({
  CHARGED:                'captured',
  PENDING:                'processing',
  PENDING_VBV:            'processing',
  AUTHORIZING:            'processing',
  STARTED:                'processing',
  AUTHORIZATION_FAILED:   'failed',
  AUTHENTICATION_FAILED:  'failed',
  JUSPAY_DECLINED:        'failed',
  COD_INITIATED:          'pending',
  VOID_INITIATED:         'cancelled',
  VOIDED:                 'cancelled'
}[s] || 'pending');

module.exports = { createSession, getOrderStatus, refund, mapStatus };
