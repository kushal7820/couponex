import React, { useState, useRef, useEffect } from 'react';
import { chatAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';

const INIT = [{ role:'assistant', content:"👋 Hi! I'm CouponX Support. Ask me anything about buying, selling, payments, OTPs, or refunds!" }];
const QUICK = ['How does escrow work?','Why is my code hidden?','How to get a refund?','How to sell a coupon?'];

export default function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [msgs, setMsgs] = useState(INIT);
  const [inp,  setInp]  = useState('');
  const [busy, setBusy] = useState(false);
  const [unread, setUnread] = useState(0);
  const boxRef = useRef(null);
  const { user } = useAuth();

  useEffect(() => { if (boxRef.current) boxRef.current.scrollTop = boxRef.current.scrollHeight; }, [msgs]);
  useEffect(() => { if (open) setUnread(0); }, [open]);

  const send = async (text) => {
    const msg = (text || inp).trim();
    if (!msg || busy) return;
    setMsgs(m => [...m, { role:'user', content:msg }]);
    setInp('');
    setBusy(true);
    try {
      const history = msgs.map(m => ({ role:m.role, content:m.content }));
      const { data } = await chatAPI.send(msg, history);
      setMsgs(m => [...m, { role:'assistant', content:data.data.content }]);
      if (!open) setUnread(u => u+1);
    } catch {
      setMsgs(m => [...m, { role:'assistant', content:"I'm having trouble. Email support@couponx.in for urgent help 🙏" }]);
    } finally { setBusy(false); }
  };

  return (
    <>
      {/* Bubble */}
      <button onClick={() => setOpen(o => !o)} style={{
        position:'fixed',bottom:'1.8rem',right:'1.8rem',zIndex:400,
        width:54,height:54,borderRadius:'50%',border:'none',cursor:'pointer',
        background:'linear-gradient(135deg,#00e5a0,#00b4ff)',fontSize:'1.3rem',
        boxShadow:'0 4px 25px rgba(0,229,160,.35)',transition:'transform .2s',
        display:'flex',alignItems:'center',justifyContent:'center'
      }}
        onMouseEnter={e=>e.currentTarget.style.transform='scale(1.1)'}
        onMouseLeave={e=>e.currentTarget.style.transform=''}>
        {open ? '✕' : '💬'}
        {unread > 0 && !open && <span style={{ position:'absolute',top:-4,right:-4,
          background:'var(--err)',color:'#fff',width:18,height:18,borderRadius:'50%',
          fontSize:'.6rem',fontWeight:700,display:'flex',alignItems:'center',justifyContent:'center' }}>{unread}</span>}
      </button>

      {/* Window */}
      {open && (
        <div style={{ position:'fixed',bottom:'5.5rem',right:'1.8rem',zIndex:400,
          width:340,height:490,background:'var(--sur)',border:'1px solid var(--bdr)',
          borderRadius:20,display:'flex',flexDirection:'column',overflow:'hidden',
          boxShadow:'0 20px 60px rgba(0,0,0,.55)',animation:'fu .25s ease' }}>

          {/* Header */}
          <div style={{ padding:'.9rem 1.1rem',borderBottom:'1px solid var(--bdr)',
            background:'var(--sur2)',display:'flex',alignItems:'center',gap:'.65rem' }}>
            <div style={{ width:9,height:9,borderRadius:'50%',background:'var(--acc)',animation:'pulse 1.5s ease infinite' }}/>
            <div>
              <div style={{ fontFamily:'Syne,sans-serif',fontWeight:700,fontSize:'.88rem' }}>CouponX Support</div>
              <div style={{ fontSize:'.65rem',color:'var(--mut)' }}>AI-powered · Instant replies</div>
            </div>
          </div>

          {/* Messages */}
          <div ref={boxRef} style={{ flex:1,overflowY:'auto',padding:'1rem',display:'flex',flexDirection:'column',gap:'.75rem' }}>
            {msgs.map((m,i) => (
              <div key={i} style={{ display:'flex',gap:'.55rem',flexDirection:m.role==='user'?'row-reverse':'row',alignItems:'flex-end' }}>
                <div style={{ width:26,height:26,borderRadius:'50%',flexShrink:0,fontSize:'.75rem',
                  background:m.role==='assistant'?'linear-gradient(135deg,#00e5a0,#00b4ff)':'var(--pur)',
                  display:'flex',alignItems:'center',justifyContent:'center',color:m.role==='assistant'?'#000':'#fff' }}>
                  {m.role==='assistant'?'🤖':(user?.name?.[0]||'U')}
                </div>
                <div style={{ maxWidth:'78%',padding:'.6rem .85rem',borderRadius:12,fontSize:'.82rem',lineHeight:1.55,
                  background:m.role==='assistant'?'var(--sur2)':'var(--pur)',
                  border:m.role==='assistant'?'1px solid var(--bdr)':'none',
                  color:m.role==='user'?'#fff':'var(--txt)' }}>
                  {m.content}
                </div>
              </div>
            ))}
            {busy && (
              <div style={{ display:'flex',gap:'.55rem',alignItems:'flex-end' }}>
                <div style={{ width:26,height:26,borderRadius:'50%',background:'linear-gradient(135deg,#00e5a0,#00b4ff)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:'.75rem' }}>🤖</div>
                <div style={{ background:'var(--sur2)',border:'1px solid var(--bdr)',padding:'.6rem .85rem',borderRadius:12,display:'flex',gap:4 }}>
                  {[0,150,300].map(d=><span key={d} style={{ width:6,height:6,borderRadius:'50%',background:'var(--mut)',display:'inline-block',animation:`pulse 1s ${d}ms ease infinite` }}/>)}
                </div>
              </div>
            )}
            {msgs.length === 1 && (
              <div style={{ display:'flex',flexWrap:'wrap',gap:'.38rem' }}>
                {QUICK.map(q=>(
                  <button key={q} onClick={()=>send(q)} style={{ background:'rgba(0,229,160,.08)',border:'1px solid rgba(0,229,160,.2)',
                    color:'var(--acc)',padding:'.28rem .6rem',borderRadius:100,fontSize:'.68rem',cursor:'pointer' }}>{q}</button>
                ))}
              </div>
            )}
          </div>

          {/* Input */}
          <div style={{ padding:'.7rem .9rem',borderTop:'1px solid var(--bdr)',background:'var(--sur2)',display:'flex',gap:'.5rem' }}>
            <input className="fi" style={{ flex:1,padding:'.52rem .85rem',fontSize:'.83rem' }}
              value={inp} onChange={e=>setInp(e.target.value)}
              onKeyDown={e=>e.key==='Enter'&&send()}
              placeholder="Type a message..." />
            <button onClick={()=>send()} disabled={busy||!inp.trim()} style={{
              background:'var(--acc)',color:'#000',border:'none',width:34,height:34,
              borderRadius:9,cursor:'pointer',fontSize:'.95rem',flexShrink:0,
              opacity:busy||!inp.trim()?.5:1,transition:'opacity .2s' }}>➤</button>
          </div>
        </div>
      )}
    </>
  );
}
