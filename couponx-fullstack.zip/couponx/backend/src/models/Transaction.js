const mongoose = require('mongoose');

const noteSchema = new mongoose.Schema({
  msg: String,
  by:  { type: String, default: 'system' },
  at:  { type: Date, default: Date.now }
}, { _id: false });

const transactionSchema = new mongoose.Schema({
  txnId:  { type: String, required: true, unique: true },
  coupon: { type: mongoose.Schema.Types.ObjectId, ref: 'Coupon', required: true },
  buyer:  { type: mongoose.Schema.Types.ObjectId, ref: 'User',   required: true },
  seller: { type: mongoose.Schema.Types.ObjectId, ref: 'User',   required: true },

  amount:          { type: Number, required: true },
  platformFee:     { type: Number, default: 0 },
  sellerPayout:    { type: Number, required: true },

  // JusPay payment details
  payment: {
    orderId:   String,
    sessionId: String,
    paymentId: String,
    method:    String,
    status: {
      type: String,
      enum: ['pending','processing','captured','failed','refunded','cancelled'],
      default: 'pending'
    },
    paidAt:       Date,
    refundId:     String,
    refundedAt:   Date,
    refundReason: String,
    raw:          mongoose.Schema.Types.Mixed
  },

  // Escrow lifecycle
  escrow: {
    status: {
      type: String,
      enum: [
        'awaiting_payment',   // Buyer hasn't paid yet
        'payment_received',   // Money captured, held in escrow
        'validating',         // Coupon being validated
        'otp_pending',        // OTP sent to buyer
        'released',           // Escrow released to seller ✅
        'aborted',            // Validation failed → refund triggered
        'disputed'            // Dispute raised
      ],
      default: 'awaiting_payment'
    },
    heldAt:       Date,
    releasedAt:   Date,
    abortedAt:    Date,
    abortReason:  String
  },

  // Coupon validation result
  validation: {
    status:    { type: String, enum: ['not_started','in_progress','passed','failed'], default: 'not_started' },
    failReason: String,
    doneAt:    Date,
    attempts:  { type: Number, default: 0 }
  },

  // Overall transaction status
  status: {
    type: String,
    enum: ['initiated','payment_pending','in_escrow','completed','failed','refunded','disputed'],
    default: 'initiated'
  },

  completedAt: Date,
  notes:       [noteSchema],

  // Post-transaction ratings
  buyerRating:  { score: Number, comment: String, at: Date },
  sellerRating: { score: Number, comment: String, at: Date }
}, { timestamps: true });

transactionSchema.index({ txnId: 1 });
transactionSchema.index({ buyer: 1, status: 1 });
transactionSchema.index({ seller: 1, status: 1 });
transactionSchema.index({ 'payment.orderId': 1 });

module.exports = mongoose.model('Transaction', transactionSchema);
