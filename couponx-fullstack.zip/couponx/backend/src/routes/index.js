const express = require('express');
const { body } = require('express-validator');
const r = express.Router();

const auth    = require('../controllers/auth');
const coupon  = require('../controllers/coupon');
const payment = require('../controllers/payment');
const chat    = require('../controllers/chat');
const { protect, restrictTo, optionalAuth } = require('../middleware/auth');
const { authLimit, paymentLimit, chatLimit, couponLimit } = require('../middleware/security');

/* ── Health ──────────────────────────────────────────────── */
r.get('/health', (_, res) => res.json({ ok: true, ts: new Date() }));

/* ── Auth ────────────────────────────────────────────────── */
r.post('/auth/register', authLimit, [
  body('name').trim().notEmpty().isLength({ max: 60 }),
  body('email').isEmail().normalizeEmail(),
  body('password').isLength({ min: 8 }).matches(/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/).withMessage('Password must have uppercase, lowercase and a number'),
  body('role').optional().isIn(['buyer','seller'])
], auth.register);

r.post('/auth/login', authLimit, [
  body('email').isEmail().normalizeEmail(),
  body('password').notEmpty()
], auth.login);

r.post('/auth/refresh', auth.refresh);
r.post('/auth/logout', protect, auth.logout);
r.get('/auth/me', protect, auth.me);

/* ── Coupons ─────────────────────────────────────────────── */
r.get('/coupons',              optionalAuth, coupon.list);
r.get('/coupons/my/listings',  protect, restrictTo('seller','admin'), coupon.myListings);
r.get('/coupons/:id',          optionalAuth, coupon.get);
r.post('/coupons', protect, restrictTo('seller','admin'), couponLimit, [
  body('brand').trim().notEmpty().isLength({ max: 100 }),
  body('category').isIn(['food','shopping','travel','health','entertainment','other']),
  body('description').trim().notEmpty().isLength({ max: 500 }),
  body('couponCode').trim().notEmpty().isLength({ min: 3, max: 50 }),
  body('faceValue').isFloat({ min: 1 }),
  body('salePrice').isFloat({ min: 1 }),
  body('expiryDate').isISO8601()
], coupon.create);
r.delete('/coupons/:id', protect, coupon.remove);

/* ── Payments ────────────────────────────────────────────── */
// Webhook must receive raw body — registered before json parser in server.js
r.post('/payments/webhook', payment.webhook);

r.post('/payments/initiate',    protect, restrictTo('buyer','admin'), paymentLimit, payment.initiate);
r.post('/payments/verify-otp',  protect, payment.verifyOTP);
r.get('/payments/status/:txnId',protect, payment.status);
r.get('/payments/history',      protect, payment.history);
r.get('/payments/callback',     payment.callback);

/* ── Chat ────────────────────────────────────────────────── */
r.post('/chat', chatLimit, optionalAuth, [
  body('message').trim().notEmpty().isLength({ max: 600 })
], chat.message);

module.exports = r;
