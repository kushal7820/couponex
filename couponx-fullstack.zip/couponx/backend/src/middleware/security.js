const rateLimit   = require('express-rate-limit');
const helmet      = require('helmet');
const mongoSanitize = require('express-mongo-sanitize');
const hpp         = require('hpp');
const xss         = require('xss');
const logger      = require('../utils/logger');

/* ── Helmet ────────────────────────────────────────────────── */
const helmetMw = helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc:  ["'self'"],
      scriptSrc:   ["'self'"],
      styleSrc:    ["'self'", "'unsafe-inline'", "fonts.googleapis.com"],
      fontSrc:     ["'self'", "fonts.gstatic.com"],
      imgSrc:      ["'self'", "data:", "https:"],
      connectSrc:  ["'self'", "https://sandbox.juspay.in", "https://api.anthropic.com"],
      frameSrc:    ["'self'", "https://sandbox.juspay.in"]
    }
  },
  crossOriginEmbedderPolicy: false
});

/* ── Rate Limiters ─────────────────────────────────────────── */
const makeLimit = (windowMs, max, msg) => rateLimit({
  windowMs, max, standardHeaders: true, legacyHeaders: false,
  handler: (req, res) => {
    logger.warn(`Rate limit hit: ${req.ip} → ${req.originalUrl}`);
    res.status(429).json({ success: false, message: msg });
  }
});

const globalLimit   = makeLimit(15 * 60 * 1000, 300, 'Too many requests. Please slow down.');
const authLimit     = makeLimit(15 * 60 * 1000, 10,  'Too many login attempts. Try again in 15 min.');
const paymentLimit  = makeLimit(60 * 60 * 1000, 20,  'Too many payment attempts. Try again later.');
const chatLimit     = makeLimit(60 * 1000,       30,  'Too many messages. Please wait a moment.');
const couponLimit   = makeLimit(60 * 60 * 1000, 15,  'Too many listings. Try again later.');

/* ── XSS sanitizer ─────────────────────────────────────────── */
const sanitizeXSS = (req, _, next) => {
  const clean = (obj) => {
    if (!obj || typeof obj !== 'object') return;
    for (const k of Object.keys(obj)) {
      if (typeof obj[k] === 'string') obj[k] = xss(obj[k]);
      else if (typeof obj[k] === 'object') clean(obj[k]);
    }
  };
  clean(req.body);
  clean(req.query);
  next();
};

/* ── Request logger ────────────────────────────────────────── */
const reqLogger = (req, res, next) => {
  const t = Date.now();
  res.on('finish', () => {
    const ms = Date.now() - t;
    const lvl = res.statusCode >= 500 ? 'error' : res.statusCode >= 400 ? 'warn' : 'info';
    logger[lvl](`${req.method} ${req.originalUrl} ${res.statusCode} ${ms}ms`, { ip: req.ip, user: req.user?.id });
  });
  next();
};

module.exports = {
  helmetMw, globalLimit, authLimit, paymentLimit, chatLimit, couponLimit,
  mongoSanitize: mongoSanitize({ replaceWith: '_' }),
  hpp: hpp(),
  sanitizeXSS,
  reqLogger
};
