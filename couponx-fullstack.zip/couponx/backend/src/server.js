require('dotenv').config();
const express = require('express');
const cors    = require('cors');
const cron    = require('node-cron');

const connectDB = require('./config/db');
const routes    = require('./routes/index');
const logger    = require('./utils/logger');
const {
  helmetMw, globalLimit, mongoSanitize, hpp,
  sanitizeXSS, reqLogger
} = require('./middleware/security');

const app = express();
connectDB();

/* ── Security ─────────────────────────────────────────────── */
app.use(helmetMw);
app.use(cors({
  origin: (process.env.FRONTEND_URL || 'http://localhost:3000').split(','),
  credentials: true,
  methods: ['GET','POST','PUT','DELETE','PATCH'],
  allowedHeaders: ['Content-Type','Authorization']
}));
app.use(globalLimit);
app.use(mongoSanitize);
app.use(hpp);
app.use(reqLogger);

/* ── Body Parsing ─────────────────────────────────────────── */
// Webhook route needs raw body BEFORE json parser
app.use('/api/payments/webhook', express.raw({ type: '*/*' }));
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: true, limit: '10kb' }));
app.use(sanitizeXSS);

/* ── Routes ───────────────────────────────────────────────── */
app.use('/api', routes);

/* ── 404 ──────────────────────────────────────────────────── */
app.use((req, res) => res.status(404).json({ success: false, message: `${req.originalUrl} not found` }));

/* ── Global Error Handler ─────────────────────────────────── */
app.use((err, req, res, next) => {
  logger.error('Unhandled', { msg: err.message, stack: err.stack });
  if (err.code === 11000) {
    const field = Object.keys(err.keyValue || {})[0] || 'field';
    return res.status(409).json({ success: false, message: `${field} already exists.` });
  }
  if (err.name === 'ValidationError') {
    const msgs = Object.values(err.errors).map(e => e.message);
    return res.status(400).json({ success: false, message: msgs.join('. ') });
  }
  res.status(err.statusCode || 500).json({
    success: false,
    message: process.env.NODE_ENV === 'production' ? 'Something went wrong.' : err.message
  });
});

/* ── Cron: expire coupons ─────────────────────────────────── */
cron.schedule('0 * * * *', async () => {
  try {
    const Coupon = require('./models/Coupon');
    const r = await Coupon.updateMany(
      { expiryDate: { $lt: new Date() }, status: { $in: ['active','pending_review'] } },
      { $set: { status: 'expired' } }
    );
    if (r.modifiedCount) logger.info(`Cron: expired ${r.modifiedCount} coupons`);
  } catch (e) { logger.error('Cron error', { e: e.message }); }
});

/* ── Start ────────────────────────────────────────────────── */
const PORT = process.env.PORT || 5000;
const server = app.listen(PORT, () =>
  logger.info(`CouponX API listening on :${PORT} [${process.env.NODE_ENV || 'development'}]`)
);

process.on('unhandledRejection', err => { logger.error('UnhandledRejection', { msg: err.message }); server.close(() => process.exit(1)); });
process.on('SIGTERM', ()          => server.close(() => { logger.info('Graceful shutdown'); process.exit(0); }));

module.exports = app;
