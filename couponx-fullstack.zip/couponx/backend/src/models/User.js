const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  name:     { type: String, required: true, trim: true, maxlength: 60 },
  email:    { type: String, required: true, unique: true, lowercase: true, match: [/^\S+@\S+\.\S+$/, 'Invalid email'] },
  password: { type: String, required: true, minlength: 8, select: false },
  phone:    { type: String, default: '' },
  role:     { type: String, enum: ['buyer', 'seller', 'admin'], default: 'buyer' },

  isActive:   { type: Boolean, default: true },
  isVerified: { type: Boolean, default: false },

  trustScore:             { type: Number, default: 100, min: 0, max: 100 },
  totalTransactions:      { type: Number, default: 0 },
  successfulTransactions: { type: Number, default: 0 },

  wallet: {
    balance:       { type: Number, default: 0 },
    escrowBalance: { type: Number, default: 0 }
  },

  // Security
  loginAttempts:    { type: Number, default: 0 },
  lockUntil:        { type: Date },
  refreshToken:     { type: String, select: false },
  passwordChanged:  { type: Date },
  lastLogin:        { type: Date }
}, { timestamps: true });

// Hash password
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 12);
  this.passwordChanged = new Date();
  next();
});

userSchema.methods.matchPassword = async function (plain) {
  return bcrypt.compare(plain, this.password);
};

userSchema.methods.isLocked = function () {
  return this.lockUntil && this.lockUntil > Date.now();
};

userSchema.methods.incAttempts = async function () {
  if (this.lockUntil && this.lockUntil < Date.now()) {
    return this.updateOne({ $set: { loginAttempts: 1 }, $unset: { lockUntil: 1 } });
  }
  const updates = { $inc: { loginAttempts: 1 } };
  if (this.loginAttempts + 1 >= 5) {
    updates.$set = { lockUntil: Date.now() + 2 * 60 * 60 * 1000 }; // 2 hr lock
  }
  return this.updateOne(updates);
};

userSchema.methods.passwordChangedAfter = function (jwtIat) {
  if (this.passwordChanged) {
    return Math.floor(this.passwordChanged.getTime() / 1000) > jwtIat;
  }
  return false;
};

userSchema.virtual('successRate').get(function () {
  return this.totalTransactions === 0 ? 100
    : Math.round((this.successfulTransactions / this.totalTransactions) * 100);
});

userSchema.set('toJSON', { virtuals: true });

module.exports = mongoose.model('User', userSchema);
