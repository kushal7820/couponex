import React, { createContext, useContext, useState, useEffect } from 'react';
import { authAPI } from '../services/api';

const Ctx = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser]       = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const t = localStorage.getItem('cx_token');
    if (t) {
      authAPI.me().then(r => setUser(r.data.user)).catch(() => localStorage.clear()).finally(() => setLoading(false));
    } else setLoading(false);
  }, []);

  const login = async (email, password) => {
    const { data } = await authAPI.login({ email, password });
    localStorage.setItem('cx_token', data.accessToken);
    localStorage.setItem('cx_refresh', data.refreshToken);
    setUser(data.user);
    return data.user;
  };

  const register = async (form) => {
    const { data } = await authAPI.register(form);
    localStorage.setItem('cx_token', data.accessToken);
    localStorage.setItem('cx_refresh', data.refreshToken);
    setUser(data.user);
    return data.user;
  };

  const logout = async () => {
    try { await authAPI.logout(); } catch {}
    localStorage.clear();
    setUser(null);
  };

  return <Ctx.Provider value={{ user, loading, login, register, logout }}>{children}</Ctx.Provider>;
};

export const useAuth = () => useContext(Ctx);
