import React, { useState } from 'react';
import { couponAPI } from '../services/api';
import toast from 'react-hot-toast';

const CATS = ['food','shopping','travel','health','entertainment','other'];

export default function SellCoupon() {
  const today = new Date(); today.setDate(today.getDate() + 3);
  const minDate = today.toISOString().split('T')[0];

  const [form, setForm] = useState({
    brand:'', category:'food', description:'', couponCode:'',
    faceValue:'', salePrice:'', minOrder:'', expiryDate:'', terms:'', applicableOn:''
  });
  const [busy, setBusy]     = useState(false);
  const [success, setSuccess] = useState(null);
  const [err, setErr]       = useState('');

  const set = k => e => setForm(f => ({ ...f, [k]: e.target.value }));

  const savPct = form.faceValue && form.salePrice
    ? Math.round(((form.faceValue - form.salePrice) / form.faceValue) * 100)
    : null;

  const submit = async e => {
    e.preventDefault(); setErr(''); setBusy(true);
    if (Number(form.salePrice) >= Number(form.faceValue)) {
      setErr('Sale price must be less than face value'); setBusy(false); return;
    }
    try {
      const r = await couponAPI.create(form);
      setSuccess(r.data.data);
      toast.success('Coupon listed! AI validation underway.');
      setForm({ brand:'', category:'food', description:'', couponCode:'', faceValue:'', salePrice:'', minOrder:'', expiryDate:'', terms:'', applicableOn:'' });
    } catch (e) {
      setErr(e.response?.data?.message || e.response?.data?.errors?.[0]?.msg || 'Failed to list coupon');
    } finally { setBusy(false); }
  };

  return (
    <div className="page">
      <div className="container" style={{ paddingTop:'2rem', paddingBottom:'4rem', maxWidth:680 }}>
        <div style={{ marginBottom:'2rem' }}>
          <div className="bdg bdg-a" style={{ marginBottom:'.6rem' }}>SELL COUPON</div>
          <h1 style={{ fontSize:'clamp(1.8rem,4vw,2.6rem)', marginBottom:'.4rem' }}>List Your Coupon</h1>
          <p style={{ color:'var(--mut)', fontSize:'.9rem' }}>
            Your coupon code is <strong style={{ color:'var(--acc)' }}>AES-256 encrypted</strong> immediately on submission.
            It is never readable — not even by admins — until the buyer completes OTP verification.
          </p>
        </div>

        {success && (
          <div style={{ background:'rgba(0,229,160,.08)', border:'1px solid rgba(0,229,160,.25)',
            borderRadius:14, padding:'1.2rem', marginBottom:'1.5rem' }}>
            <div style={{ fontWeight:700, color:'var(--acc)', marginBottom:'.4rem' }}>✅ Coupon Listed Successfully!</div>
            <div style={{ fontSize:'.85rem', color:'var(--mut)' }}>
              <strong>{success.brand}</strong> — masked as <code style={{ color:'var(--txt)' }}>{success.maskedCode}</code><br/>
              AI validation is running in the background. Your coupon will go live within seconds.
            </div>
          </div>
        )}

        <form onSubmit={submit} className="card">
          {err && (
            <div style={{ background:'rgba(239,68,68,.1)', border:'1px solid rgba(239,68,68,.25)',
              color:'var(--err)', padding:'.7rem 1rem', borderRadius:10, marginBottom:'1rem', fontSize:'.85rem' }}>{err}</div>
          )}

          <div className="f2">
            <div className="fg">
              <label className="fl">Brand / Platform *</label>
              <input className="fi" placeholder="e.g. Swiggy, Amazon…" value={form.brand} onChange={set('brand')} required />
            </div>
            <div className="fg">
              <label className="fl">Category *</label>
              <select className="fs" value={form.category} onChange={set('category')}>
                {CATS.map(c => <option key={c} value={c}>{c.charAt(0).toUpperCase() + c.slice(1)}</option>)}
              </select>
            </div>
          </div>

          <div className="fg">
            <label className="fl">Description *</label>
            <input className="fi" placeholder="e.g. ₹300 off on orders above ₹699" value={form.description} onChange={set('description')} required maxLength={500}/>
          </div>

          <div className="fg">
            <label className="fl">Coupon Code * <span style={{ color:'var(--acc)', fontSize:'.7rem' }}>(🔒 encrypted on submission)</span></label>
            <input className="fi" placeholder="e.g. SAVE300OFF" value={form.couponCode} onChange={set('couponCode')} required style={{ fontFamily:'monospace', letterSpacing:'.08em' }}/>
          </div>

          <div className="f2">
            <div className="fg">
              <label className="fl">Face Value ₹ *</label>
              <input className="fi" type="number" min={1} placeholder="e.g. 500" value={form.faceValue} onChange={set('faceValue')} required/>
            </div>
            <div className="fg">
              <label className="fl">Your Asking Price ₹ *
                {savPct !== null && savPct > 0 && <span style={{ color:'var(--acc)', marginLeft:'.4rem' }}>({savPct}% savings for buyer)</span>}
              </label>
              <input className="fi" type="number" min={1} placeholder="e.g. 199" value={form.salePrice} onChange={set('salePrice')} required/>
            </div>
          </div>

          <div className="f2">
            <div className="fg">
              <label className="fl">Min. Order Value ₹</label>
              <input className="fi" type="number" min={0} placeholder="0 = No minimum" value={form.minOrder} onChange={set('minOrder')}/>
            </div>
            <div className="fg">
              <label className="fl">Expiry Date *</label>
              <input className="fi" type="date" min={minDate} value={form.expiryDate} onChange={set('expiryDate')} required/>
            </div>
          </div>

          <div className="fg">
            <label className="fl">Applicable On</label>
            <input className="fi" placeholder="e.g. App only, first order, specific categories" value={form.applicableOn} onChange={set('applicableOn')}/>
          </div>

          <div className="fg">
            <label className="fl">Terms & Conditions</label>
            <input className="fi" placeholder="e.g. Cannot be clubbed with other offers" value={form.terms} onChange={set('terms')}/>
          </div>

          {/* Fee info */}
          <div style={{ background:'var(--sur2)', borderRadius:10, padding:'1rem', marginBottom:'1rem', fontSize:'.82rem', color:'var(--mut)' }}>
            💡 <strong style={{ color:'var(--txt)' }}>Platform fee:</strong> 5% deducted from your asking price on successful sale.
            {form.salePrice && <span style={{ color:'var(--acc)', marginLeft:'.4rem' }}>You receive ₹{Math.round(form.salePrice * 0.95)} after fee.</span>}
          </div>

          <button className="btn btn-primary btn-full" type="submit" disabled={busy}>
            {busy ? '🤖 Encrypting & Listing…' : '🔐 Encrypt & List Coupon →'}
          </button>
        </form>
      </div>
    </div>
  );
}
