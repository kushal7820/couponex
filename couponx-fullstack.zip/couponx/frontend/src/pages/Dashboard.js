import React, { useState, useEffect } from 'react';
import { paymentAPI, couponAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';

const statusColor = s => ({
  completed:'var(--acc)', refunded:'var(--amb)', failed:'var(--err)',
  in_escrow:'#00b4ff', payment_pending:'var(--amb)', initiated:'var(--mut)'
}[s] || 'var(--mut)');

const couponStatusColor = s => ({
  active:'var(--acc)', sold:'var(--pur)', reserved:'var(--amb)',
  expired:'var(--mut)', flagged:'var(--err)', pending_review:'var(--amb)'
}[s] || 'var(--mut)');

export default function Dashboard() {
  const { user } = useAuth();
  const nav      = useNavigate();
  const isSeller = user?.role === 'seller';
  const [tab,  setTab]  = useState(isSeller ? 'listings' : 'purchases');
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    const fn = tab === 'listings' ? couponAPI.myListings : paymentAPI.history;
    fn().then(r => setData(r.data.data)).catch(() => toast.error('Failed to load data')).finally(() => setLoading(false));
  }, [tab]);

  const removeCoupon = async (id) => {
    if (!window.confirm('Remove this coupon listing?')) return;
    try { await couponAPI.remove(id); setData(d => d.filter(c => c._id !== id)); toast.success('Removed'); }
    catch (e) { toast.error(e.response?.data?.message || 'Failed to remove'); }
  };

  return (
    <div className="page">
      <div className="container" style={{ paddingTop:'2rem', paddingBottom:'4rem' }}>

        {/* Header */}
        <div style={{ marginBottom:'2rem' }}>
          <h1 style={{ fontSize:'2rem', marginBottom:'.4rem' }}>Dashboard</h1>
          <p style={{ color:'var(--mut)' }}>Welcome back, <strong>{user?.name}</strong> · {user?.role}</p>
        </div>

        {/* Stats row */}
        <div className="g2" style={{ gridTemplateColumns:'repeat(auto-fit,minmax(160px,1fr))', marginBottom:'2rem' }}>
          {[
            { l:'Trust Score',   v:`${user?.trustScore}/100`, c:'var(--acc)' },
            { l:'Total Txns',    v: user?.totalTransactions,  c:'var(--txt)' },
            { l:'Success Rate',  v:`${user?.successRate ?? 100}%`, c:'var(--acc)' },
            { l:'Wallet',        v:`₹${user?.wallet?.balance ?? 0}`, c:'var(--amb)' },
          ].map(({ l, v, c }) => (
            <div key={l} className="card" style={{ textAlign:'center' }}>
              <div style={{ fontFamily:'Syne,sans-serif', fontSize:'1.6rem', fontWeight:800, color:c }}>{v}</div>
              <div style={{ color:'var(--mut)', fontSize:'.78rem', marginTop:'.2rem' }}>{l}</div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div style={{ display:'flex', gap:'.5rem', marginBottom:'1.5rem' }}>
          {[
            ...(isSeller ? [{ k:'listings', l:'My Listings' }] : []),
            { k:'purchases', l:'My Purchases' },
          ].map(t => (
            <button key={t.k} className="btn btn-sm"
              onClick={() => setTab(t.k)}
              style={{
                background: tab === t.k ? 'var(--acc)' : 'transparent',
                color:      tab === t.k ? '#000' : 'var(--mut)',
                border:    `1px solid ${tab === t.k ? 'transparent' : 'var(--bdr)'}`,
              }}>{t.l}</button>
          ))}
          {isSeller && (
            <button className="btn btn-sm btn-primary" style={{ marginLeft:'auto' }} onClick={() => nav('/sell')}>
              + New Listing
            </button>
          )}
        </div>

        {/* Content */}
        {loading ? (
          <div style={{ display:'flex', flexDirection:'column', gap:'1rem' }}>
            {[...Array(3)].map((_,i) => <div key={i} className="skel" style={{ height:80 }}/>)}
          </div>
        ) : data.length === 0 ? (
          <div style={{ textAlign:'center', padding:'4rem', color:'var(--mut)' }}>
            <div style={{ fontSize:'3rem', marginBottom:'1rem' }}>
              {tab === 'listings' ? '🏪' : '🛒'}
            </div>
            <p>{tab === 'listings' ? 'No listings yet.' : 'No purchases yet.'}</p>
            <button className="btn btn-primary" style={{ marginTop:'1rem' }}
              onClick={() => nav(tab === 'listings' ? '/sell' : '/marketplace')}>
              {tab === 'listings' ? 'List a Coupon' : 'Browse Marketplace'}
            </button>
          </div>
        ) : (
          <div style={{ display:'flex', flexDirection:'column', gap:'.85rem' }}>
            {tab === 'listings' ? (
              data.map(c => (
                <div key={c._id} className="card" style={{ display:'flex', justifyContent:'space-between', alignItems:'center', flexWrap:'wrap', gap:'1rem', padding:'1rem 1.3rem' }}>
                  <div>
                    <div style={{ fontWeight:700, marginBottom:'.25rem' }}>{c.brand}</div>
                    <div style={{ fontSize:'.8rem', color:'var(--mut)' }}>{c.description}</div>
                    <div style={{ fontSize:'.75rem', marginTop:'.3rem' }}>
                      <code style={{ color:'var(--txt)' }}>{c.maskedCode}</code>
                      <span style={{ margin:'0 .5rem', color:'var(--bdr)' }}>·</span>
                      <span style={{ color:'var(--acc)' }}>₹{c.salePrice}</span>
                      <span style={{ margin:'0 .5rem', color:'var(--bdr)' }}>·</span>
                      <span>AI Score: {c.ai?.score ?? '—'}</span>
                    </div>
                  </div>
                  <div style={{ display:'flex', alignItems:'center', gap:'1rem' }}>
                    <span style={{
                      background: `${couponStatusColor(c.status)}22`,
                      color: couponStatusColor(c.status),
                      border: `1px solid ${couponStatusColor(c.status)}44`,
                      padding:'.25rem .65rem', borderRadius:100, fontSize:'.72rem', fontWeight:600, textTransform:'capitalize'
                    }}>{c.status.replace(/_/g,' ')}</span>
                    <span style={{ fontSize:'.78rem', color:'var(--mut)' }}>
                      {Math.ceil((new Date(c.expiryDate) - Date.now()) / 86400000)}d left
                    </span>
                    {!['sold','reserved'].includes(c.status) && (
                      <button className="btn btn-sm btn-danger" onClick={() => removeCoupon(c._id)}>Remove</button>
                    )}
                  </div>
                </div>
              ))
            ) : (
              data.map(t => (
                <div key={t._id} className="card" style={{ display:'flex', justifyContent:'space-between', alignItems:'center', flexWrap:'wrap', gap:'1rem', padding:'1rem 1.3rem' }}>
                  <div>
                    <div style={{ fontWeight:700, marginBottom:'.25rem' }}>{t.coupon?.brand || 'Coupon'}</div>
                    <div style={{ fontSize:'.8rem', color:'var(--mut)' }}>{t.coupon?.description}</div>
                    <div style={{ fontSize:'.75rem', color:'var(--mut)', marginTop:'.3rem' }}>
                      {new Date(t.createdAt).toLocaleDateString('en-IN')} · Escrow: {(t.escrow?.status || '').replace(/_/g,' ')}
                    </div>
                  </div>
                  <div style={{ display:'flex', alignItems:'center', gap:'1rem' }}>
                    <span style={{
                      background: `${statusColor(t.status)}22`,
                      color: statusColor(t.status),
                      border: `1px solid ${statusColor(t.status)}44`,
                      padding:'.25rem .65rem', borderRadius:100, fontSize:'.72rem', fontWeight:600, textTransform:'capitalize'
                    }}>{t.status.replace(/_/g,' ')}</span>
                    <span style={{ fontFamily:'Syne,sans-serif', fontWeight:800, color:'var(--acc)' }}>₹{t.amount}</span>
                    {['in_escrow','payment_pending'].includes(t.status) && (
                      <button className="btn btn-sm btn-purple" onClick={() => nav(`/payment/processing?txn=${t.txnId}`)}>
                        View →
                      </button>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}
