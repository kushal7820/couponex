import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { paymentAPI } from '../services/api';
import toast from 'react-hot-toast';

const STEPS = [
  { key:'payment',    label:'Payment',   icon:'💳' },
  { key:'escrow',     label:'Escrow',    icon:'🔒' },
  { key:'validate',   label:'Validate',  icon:'🤖' },
  { key:'otp',        label:'OTP',       icon:'📱' },
  { key:'done',       label:'Complete',  icon:'✅' },
];

const escrowToStep = {
  awaiting_payment: 0, payment_received: 1,
  validating: 2, otp_pending: 3, released: 4, aborted: -1
};

export default function Payment() {
  const [sp] = useSearchParams();
  const nav  = useNavigate();
  const txnId = sp.get('txn');
  const isFailed = window.location.pathname.includes('failed');

  const [txn,      setTxn]      = useState(null);
  const [otp,      setOtp]      = useState('');
  const [revealed, setRevealed] = useState(null);
  const [loading,  setLoading]  = useState(false);
  const [err,      setErr]      = useState('');
  const [stepIdx,  setStepIdx]  = useState(0);

  const poll = useCallback(async () => {
    if (!txnId) return;
    try {
      const r = await paymentAPI.status(txnId);
      const d = r.data.data;
      setTxn(d);
      const idx = escrowToStep[d.escrowStatus] ?? 0;
      setStepIdx(idx);
    } catch { /* silent */ }
  }, [txnId]);

  useEffect(() => {
    poll();
    const t = setInterval(poll, 3000);
    return () => clearInterval(t);
  }, [poll]);

  const verify = async () => {
    if (otp.length !== 6) { setErr('Enter the 6-digit OTP'); return; }
    setLoading(true); setErr('');
    try {
      const r = await paymentAPI.verifyOTP(txnId, otp);
      setRevealed(r.data.data);
      setStepIdx(4);
      toast.success('🎉 Coupon unlocked!');
    } catch (e) {
      const msg = e.response?.data?.message || 'OTP verification failed';
      setErr(msg);
      toast.error(msg);
    } finally { setLoading(false); }
  };

  if (!txnId) return (
    <div className="page" style={{ display:'flex', alignItems:'center', justifyContent:'center' }}>
      <div className="card" style={{ textAlign:'center', maxWidth:400 }}>
        <div style={{ fontSize:'3rem', marginBottom:'1rem' }}>❌</div>
        <h2>Invalid Transaction</h2>
        <p style={{ color:'var(--mut)', margin:'.5rem 0 1.5rem' }}>No transaction ID found in this URL.</p>
        <button className="btn btn-primary btn-full" onClick={() => nav('/marketplace')}>Browse Coupons</button>
      </div>
    </div>
  );

  const isAborted  = txn?.status === 'refunded' || txn?.escrow?.status === 'aborted';
  const isComplete = txn?.status === 'completed' || revealed;

  return (
    <div className="page" style={{ display:'flex', alignItems:'center', justifyContent:'center', padding:'2rem' }}>
      <div style={{ width:'100%', maxWidth:560 }}>
        <div style={{ marginBottom:'1.5rem' }}>
          <h1 style={{ fontSize:'1.8rem', marginBottom:'.3rem' }}>Transaction Status</h1>
          <p style={{ color:'var(--mut)', fontSize:'.82rem' }}>
            ID: <code style={{ color:'var(--acc)', fontSize:'.8rem' }}>{txnId}</code>
          </p>
        </div>

        {/* Step tracker */}
        <div className="card" style={{ marginBottom:'1.5rem' }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
            {STEPS.map((s, i) => {
              const done    = isAborted ? false : i < stepIdx;
              const active  = isAborted ? false : i === stepIdx;
              const failed  = isAborted && i <= 2;
              const color   = failed ? '#ef4444' : done ? '#00e5a0' : active ? '#f59e0b' : '#6b7a99';
              return (
                <div key={s.key} style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:'.35rem', flex:1 }}>
                  <div style={{
                    width:34, height:34, borderRadius:'50%', background:color,
                    display:'flex', alignItems:'center', justifyContent:'center',
                    fontSize:'.85rem', fontWeight:700,
                    color: (done || active) && !failed ? '#000' : '#fff',
                    transition:'all .4s', boxShadow: active ? `0 0 14px ${color}66` : 'none'
                  }}>
                    {failed ? '✕' : done ? '✓' : active ? '…' : s.icon}
                  </div>
                  <span style={{ fontSize:'.65rem', color, fontWeight:600, textAlign:'center' }}>{s.label}</span>
                </div>
              );
            })}
          </div>
          {/* Progress bar */}
          <div style={{ height:4, background:'var(--sur2)', borderRadius:4, marginTop:'1rem', overflow:'hidden' }}>
            <div style={{
              height:'100%', borderRadius:4,
              background: isAborted ? 'var(--err)' : 'linear-gradient(90deg, var(--acc), #00b4ff)',
              width: isAborted ? '40%' : `${(stepIdx / (STEPS.length - 1)) * 100}%`,
              transition:'width .5s ease'
            }}/>
          </div>
        </div>

        {/* Txn info */}
        {txn && (
          <div className="card" style={{ marginBottom:'1.5rem' }}>
            {[
              ['Coupon',        txn.coupon?.brand || '—'],
              ['Amount Paid',   `₹${txn.amount}`],
              ['Payment',       txn.paymentStatus],
              ['Escrow Status', (txn.escrowStatus || '').replace(/_/g,' ')],
            ].map(([k,v]) => (
              <div key={k} style={{ display:'flex', justifyContent:'space-between', marginBottom:'.55rem', fontSize:'.85rem' }}>
                <span style={{ color:'var(--mut)' }}>{k}</span>
                <span style={{ fontWeight:600, color: k==='Amount Paid' ? 'var(--acc)' : 'var(--txt)', textTransform:'capitalize' }}>{v}</span>
              </div>
            ))}
          </div>
        )}

        {/* ── ABORTED / REFUNDED ── */}
        {isAborted && (
          <div className="card" style={{ borderColor:'rgba(239,68,68,.3)', textAlign:'center', padding:'2rem', marginBottom:'1.5rem' }}>
            <div style={{ fontSize:'3rem', marginBottom:'.8rem' }}>💸</div>
            <h3 style={{ color:'var(--err)', marginBottom:'.5rem' }}>Transaction Aborted — Refund Initiated</h3>
            <p style={{ color:'var(--mut)', fontSize:'.87rem', lineHeight:1.6 }}>
              Coupon validation failed or too many incorrect OTP attempts.<br/>
              <strong style={{ color:'var(--txt)' }}>₹{txn?.amount}</strong> will be refunded to your original payment method within <strong style={{ color:'var(--txt)' }}>3–5 business days</strong>.
            </p>
            <button className="btn btn-secondary" style={{ marginTop:'1.5rem' }} onClick={() => nav('/marketplace')}>
              Browse Other Coupons
            </button>
          </div>
        )}

        {/* ── OTP ENTRY ── */}
        {!isAborted && !revealed && txn?.escrowStatus === 'otp_pending' && (
          <div className="card" style={{ borderColor:'rgba(0,229,160,.25)', marginBottom:'1.5rem' }}>
            <div style={{ textAlign:'center', marginBottom:'1.5rem' }}>
              <div style={{ fontSize:'2.5rem', marginBottom:'.5rem' }}>📱</div>
              <h3 style={{ marginBottom:'.4rem' }}>Enter OTP to Claim Coupon</h3>
              <p style={{ color:'var(--mut)', fontSize:'.85rem', lineHeight:1.55 }}>
                A 6-digit OTP was sent to your registered phone/email.<br/>
                Enter it below to decrypt and reveal your coupon code.
              </p>
            </div>

            <input
              className="otp-inp"
              type="text" inputMode="numeric" maxLength={6}
              value={otp} onChange={e => setOtp(e.target.value.replace(/\D/g,''))}
              onKeyDown={e => e.key === 'Enter' && verify()}
              placeholder="000000"
            />

            {err && (
              <p style={{ color:'var(--err)', fontSize:'.82rem', textAlign:'center', marginTop:'.6rem' }}>{err}</p>
            )}

            <button className="btn btn-primary btn-full" style={{ marginTop:'1rem' }}
              onClick={verify} disabled={loading || otp.length !== 6}>
              {loading ? 'Verifying…' : '🔓 Verify & Reveal Coupon'}
            </button>

            <div style={{ display:'flex', justifyContent:'space-between', marginTop:'.75rem', fontSize:'.72rem', color:'var(--mut)' }}>
              <span>⏱ OTP expires in 10 minutes</span>
              <span>Max 3 attempts — then auto-refund</span>
            </div>
          </div>
        )}

        {/* ── COUPON REVEALED ── */}
        {revealed && (
          <div className="card" style={{ borderColor:'rgba(0,229,160,.4)', background:'rgba(0,229,160,.04)', textAlign:'center' }}>
            <div style={{ fontSize:'3rem', marginBottom:'.6rem' }}>🎉</div>
            <h3 style={{ color:'var(--acc)', marginBottom:'.4rem' }}>Coupon Unlocked!</h3>
            <p style={{ color:'var(--mut)', fontSize:'.85rem', marginBottom:'1.4rem', lineHeight:1.55 }}>
              Payment released to seller. Your verified coupon code is below — use it before it expires!
            </p>

            <div style={{
              background:'var(--sur2)', border:'2px solid var(--acc)',
              borderRadius:14, padding:'1.2rem', marginBottom:'1rem'
            }}>
              <div style={{ fontSize:'.72rem', color:'var(--mut)', marginBottom:'.4rem', letterSpacing:'.08em' }}>YOUR COUPON CODE</div>
              <div style={{ fontFamily:'monospace', fontSize:'2rem', fontWeight:800, color:'var(--acc)', letterSpacing:'.2em' }}>
                {revealed.couponCode}
              </div>
              <div style={{ fontSize:'.75rem', color:'var(--mut)', marginTop:'.4rem' }}>
                {revealed.brand} · Expires {new Date(revealed.expiryDate).toLocaleDateString('en-IN')}
              </div>
            </div>

            <button className="btn btn-secondary btn-full"
              onClick={() => { navigator.clipboard.writeText(revealed.couponCode); toast.success('Copied!'); }}>
              📋 Copy Code
            </button>

            {revealed.terms && (
              <p style={{ fontSize:'.73rem', color:'var(--mut)', marginTop:'1rem', lineHeight:1.5 }}>
                <strong>T&C:</strong> {revealed.terms}
              </p>
            )}
          </div>
        )}

        {/* ── WAITING STATE ── */}
        {!isAborted && !revealed && txn && !['otp_pending','released'].includes(txn.escrowStatus) && (
          <div className="card" style={{ textAlign:'center', padding:'2rem' }}>
            <div className="spin" style={{ marginBottom:'1rem' }}/>
            <h3 style={{ marginBottom:'.4rem' }}>
              {txn.escrowStatus === 'awaiting_payment' && 'Waiting for payment…'}
              {txn.escrowStatus === 'payment_received' && 'Payment received! Validating coupon…'}
              {txn.escrowStatus === 'validating'       && 'AI validating coupon authenticity…'}
            </h3>
            <p style={{ color:'var(--mut)', fontSize:'.85rem' }}>This page auto-updates every 3 seconds</p>
          </div>
        )}

        {/* Failed redirect */}
        {isFailed && !txn && (
          <div className="card" style={{ textAlign:'center', padding:'2rem', borderColor:'rgba(239,68,68,.3)' }}>
            <div style={{ fontSize:'3rem', marginBottom:'.8rem' }}>❌</div>
            <h3 style={{ color:'var(--err)', marginBottom:'.5rem' }}>Payment Failed</h3>
            <p style={{ color:'var(--mut)', fontSize:'.87rem', marginBottom:'1.5rem' }}>
              Your payment was not completed. No money was charged.
            </p>
            <button className="btn btn-primary btn-full" onClick={() => nav('/marketplace')}>Try Again</button>
          </div>
        )}
      </div>
    </div>
  );
}
