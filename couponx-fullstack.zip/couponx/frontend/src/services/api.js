import axios from 'axios';

const BASE = process.env.REACT_APP_API_URL || '/api';

const api = axios.create({ baseURL: BASE, timeout: 15000, headers: { 'Content-Type': 'application/json' } });

api.interceptors.request.use(cfg => {
  const t = localStorage.getItem('cx_token');
  if (t) cfg.headers.Authorization = `Bearer ${t}`;
  return cfg;
});

api.interceptors.response.use(r => r, async err => {
  const orig = err.config;
  if (err.response?.status === 401 && err.response?.data?.code === 'TOKEN_EXPIRED' && !orig._retry) {
    orig._retry = true;
    try {
      const rt = localStorage.getItem('cx_refresh');
      const { data } = await axios.post(`${BASE}/auth/refresh`, { refreshToken: rt });
      localStorage.setItem('cx_token', data.accessToken);
      orig.headers.Authorization = `Bearer ${data.accessToken}`;
      return api(orig);
    } catch { localStorage.clear(); window.location.href = '/login'; }
  }
  return Promise.reject(err);
});

export const authAPI = {
  register: d => api.post('/auth/register', d),
  login:    d => api.post('/auth/login', d),
  logout:   () => api.post('/auth/logout'),
  me:       () => api.get('/auth/me')
};

export const couponAPI = {
  list:       p => api.get('/coupons', { params: p }),
  get:        id => api.get(`/coupons/${id}`),
  create:     d => api.post('/coupons', d),
  remove:     id => api.delete(`/coupons/${id}`),
  myListings: () => api.get('/coupons/my/listings')
};

export const paymentAPI = {
  initiate:  id  => api.post('/payments/initiate', { couponId: id }),
  verifyOTP: (txnId, otp) => api.post('/payments/verify-otp', { txnId, otp }),
  status:    txnId => api.get(`/payments/status/${txnId}`),
  history:   () => api.get('/payments/history')
};

export const chatAPI = {
  send: (message, history) => api.post('/chat', { message, history })
};

export default api;
