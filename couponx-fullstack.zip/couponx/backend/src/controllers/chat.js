const { chat } = require('../services/ai');
const logger = require('../utils/logger');

exports.message = async (req, res) => {
  try {
    const { message, history } = req.body;
    if (!message?.trim()) return res.status(400).json({ success: false, message: 'Message required.' });
    if (message.length > 600) return res.status(400).json({ success: false, message: 'Message too long.' });

    const ctx = req.user ? { name: req.user.name, role: req.user.role } : null;
    const reply = await chat({ message: message.trim(), history: history || [], userCtx: ctx });

    res.json({ success: true, data: { ...reply, timestamp: new Date() } });
  } catch (err) {
    logger.error('Chat error', { err: err.message });
    res.status(500).json({ success: false, message: "I'm temporarily unavailable. Try again shortly." });
  }
};
