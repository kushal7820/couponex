const crypto = require('crypto');

const ALGORITHM = 'aes-256-cbc';

// Derive key safely: fallback to a deterministic key in dev if env not set
const getKey = () => {
  const k = process.env.COUPON_ENCRYPTION_KEY;
  if (k && k.length === 64) return Buffer.from(k, 'hex');
  // Dev fallback — never use in production
  return crypto.scryptSync('dev-secret', 'couponx-salt', 32);
};

/**
 * Encrypt a coupon code for secure storage.
 * Returns "ivHex:encryptedHex"
 */
const encryptCoupon = (plaintext) => {
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv(ALGORITHM, getKey(), iv);
  const encrypted = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
  return `${iv.toString('hex')}:${encrypted.toString('hex')}`;
};

/**
 * Decrypt a coupon code. Only called after successful escrow release.
 */
const decryptCoupon = (encryptedData) => {
  const [ivHex, encHex] = encryptedData.split(':');
  const iv = Buffer.from(ivHex, 'hex');
  const encrypted = Buffer.from(encHex, 'hex');
  const decipher = crypto.createDecipheriv(ALGORITHM, getKey(), iv);
  return Buffer.concat([decipher.update(encrypted), decipher.final()]).toString('utf8');
};

/**
 * Generate a cryptographically secure numeric OTP.
 */
const generateOTP = (length = 6) => {
  let otp = '';
  while (otp.length < length) {
    otp += crypto.randomInt(0, 10);
  }
  return otp.slice(0, length);
};

/**
 * Hash OTP with HMAC-SHA256 for storage. Never store plain OTPs.
 */
const hashOTP = (otp) => {
  return crypto.createHmac('sha256', process.env.JWT_SECRET || 'dev-hmac-secret')
    .update(String(otp))
    .digest('hex');
};

/**
 * Mask a coupon code for public display before purchase.
 * e.g. "SAVE500OFF" → "SAV*******"
 */
const maskCode = (code) => {
  if (!code || code.length <= 3) return '***';
  const show = Math.max(2, Math.floor(code.length * 0.25));
  return code.slice(0, show) + '*'.repeat(code.length - show);
};

/**
 * Verify JusPay webhook HMAC signature.
 */
const verifyHmac = (payload, signature, secret) => {
  try {
    const expected = crypto.createHmac('sha256', secret).update(payload).digest('hex');
    return crypto.timingSafeEqual(Buffer.from(signature, 'hex'), Buffer.from(expected, 'hex'));
  } catch {
    return false;
  }
};

module.exports = { encryptCoupon, decryptCoupon, generateOTP, hashOTP, maskCode, verifyHmac };
