/**
 * Escrow Service
 * ─────────────────────────────────────────────────────────────────
 * Flow:
 *  1. initiate()        → reserve coupon, create txn, get JusPay URL
 *  2. onPaymentSuccess()→ money in escrow, start coupon validation
 *  3. validate()        → check coupon is real + unused
 *  4. sendOTP()         → OTP generated, sent to buyer
 *  5. verifyOTP()       → OTP correct → decrypt code, release to seller
 *
 * On any failure in steps 3-5: abortAndRefund() → auto refund buyer
 * ─────────────────────────────────────────────────────────────────
 */
const { v4: uuidv4 } = require('uuid');
const Transaction = require('../models/Transaction');
const Coupon      = require('../models/Coupon');
const User        = require('../models/User');
const juspay      = require('./juspay');
const { generateOTP, hashOTP, decryptCoupon } = require('../utils/encryption');
const logger      = require('../utils/logger');

const PLATFORM_FEE_PCT = 5; // 5% platform fee

/* ─── 1. Initiate Purchase ─────────────────────────────────── */
const initiate = async ({ couponId, buyerId }) => {
  const coupon = await Coupon.findById(couponId);
  if (!coupon)                      throw new Error('Coupon not found');
  if (coupon.status !== 'active')   throw new Error('Coupon is not available');
  if (coupon.expiryDate < new Date()) throw new Error('Coupon has expired');
  if (String(coupon.seller) === String(buyerId)) throw new Error('You cannot buy your own coupon');

  const buyer = await User.findById(buyerId);
  if (!buyer?.isActive) throw new Error('Buyer account is invalid');

  const fee      = Math.round(coupon.salePrice * PLATFORM_FEE_PCT / 100);
  const payout   = coupon.salePrice - fee;
  const txnId    = `TXN-${Date.now()}-${uuidv4().slice(0,6).toUpperCase()}`;
  const orderId  = `ORD-${Date.now()}-${uuidv4().slice(0,6).toUpperCase()}`;

  // Reserve coupon so no one else can buy it
  await Coupon.findByIdAndUpdate(couponId, { status: 'reserved' });

  // Create transaction record
  const txn = await Transaction.create({
    txnId,
    coupon:       couponId,
    buyer:        buyerId,
    seller:       coupon.seller,
    amount:       coupon.salePrice,
    platformFee:  fee,
    sellerPayout: payout,
    'payment.orderId': orderId,
    status:       'payment_pending',
    'escrow.status': 'awaiting_payment',
    notes: [{ msg: 'Purchase initiated' }]
  });

  // Create JusPay session
  const session = await juspay.createSession({
    orderId,
    amount:      coupon.salePrice,
    customerId:  String(buyerId),
    email:       buyer.email,
    phone:       buyer.phone || '9999999999',
    returnUrl:   `${process.env.FRONTEND_URL}/payment/callback?txn=${txnId}`,
    description: `CouponX: ${coupon.brand} — ${coupon.description.slice(0, 60)}`
  });

  logger.info('Escrow initiated', { txnId, couponId, buyerId });

  return {
    txnId,
    orderId,
    paymentUrl: session.paymentUrl,
    amount: coupon.salePrice,
    coupon: {
      brand:      coupon.brand,
      description: coupon.description,
      maskedCode: coupon.maskedCode,   // ← only masked code, never real
      faceValue:  coupon.faceValue,
      expiryDate: coupon.expiryDate
    }
  };
};

/* ─── 2. Payment Confirmed (webhook / poll) ────────────────── */
const onPaymentSuccess = async ({ orderId, paymentId, raw }) => {
  const txn = await Transaction.findOne({ 'payment.orderId': orderId });
  if (!txn) throw new Error(`No transaction for order ${orderId}`);
  if (txn.escrow.status !== 'awaiting_payment') {
    logger.warn('Duplicate payment event ignored', { orderId });
    return txn;
  }

  txn.payment.status    = 'captured';
  txn.payment.paymentId = paymentId;
  txn.payment.paidAt    = new Date();
  txn.payment.raw       = raw;
  txn.escrow.status     = 'payment_received';
  txn.escrow.heldAt     = new Date();
  txn.status            = 'in_escrow';
  txn.notes.push({ msg: 'Payment captured — held in escrow' });
  await txn.save();

  // Kick off validation asynchronously
  validate(txn._id).catch(err => logger.error('Validation error', { txnId: txn.txnId, err: err.message }));
  return txn;
};

/* ─── 3. Validate Coupon ───────────────────────────────────── */
const validate = async (txnMongoId) => {
  const txn = await Transaction.findById(txnMongoId).populate('coupon');
  if (!txn) throw new Error('Transaction not found');

  txn.escrow.status        = 'validating';
  txn.validation.status    = 'in_progress';
  txn.validation.attempts += 1;
  txn.notes.push({ msg: 'Coupon validation started' });
  await txn.save();

  // ── Validation checks ─────────────────────────────────────
  const coupon = await Coupon.findById(txn.coupon._id);

  if (!coupon) {
    return abortAndRefund(txn._id, 'Coupon no longer exists');
  }
  if (coupon.expiryDate < new Date()) {
    return abortAndRefund(txn._id, 'Coupon expired during transaction');
  }
  if (coupon.status !== 'reserved') {
    return abortAndRefund(txn._id, 'Coupon is no longer available');
  }

  // ── Validation passed: generate OTP ───────────────────────
  const otp     = generateOTP(6);
  const otpHash = hashOTP(otp);
  const otpExp  = new Date(Date.now() + (parseInt(process.env.OTP_EXPIRY_MINUTES) || 10) * 60000);

  await Coupon.findByIdAndUpdate(coupon._id, {
    'otp.hash':      otpHash,
    'otp.expiresAt': otpExp,
    'otp.attempts':  0
  });

  txn.validation.status  = 'passed';
  txn.validation.doneAt  = new Date();
  txn.escrow.status      = 'otp_pending';
  txn.notes.push({ msg: `Validation passed. OTP generated: ${otp} (dev-visible only)` });
  await txn.save();

  logger.info('Coupon validated, OTP ready', { txnId: txn.txnId, otp /* remove in prod */ });

  // TODO: SMS/email OTP to buyer via Twilio / AWS SNS
  // await smsService.send(buyer.phone, `Your CouponX OTP: ${otp}. Valid for 10 min.`);
};

/* ─── 4+5. Verify OTP → Reveal Code → Release Escrow ──────── */
const verifyOTP = async ({ txnId, buyerId, otp }) => {
  const txn = await Transaction.findOne({ txnId });
  if (!txn)                                     throw new Error('Transaction not found');
  if (String(txn.buyer) !== String(buyerId))    throw new Error('Unauthorized');
  if (txn.escrow.status !== 'otp_pending')      throw new Error('OTP not expected at this stage');

  // Fetch coupon with encrypted code + otp (both select: false)
  const coupon = await Coupon.findById(txn.coupon).select('+encryptedCode +otp');
  if (!coupon) throw new Error('Coupon not found');

  // Max attempts guard
  if (coupon.otp.attempts >= 3) {
    await abortAndRefund(txn._id, 'Too many incorrect OTP attempts');
    throw new Error('Too many OTP attempts. Your payment has been refunded.');
  }

  // Expiry check
  if (coupon.otp.expiresAt < new Date()) {
    await abortAndRefund(txn._id, 'OTP expired without verification');
    throw new Error('OTP expired. Your payment has been refunded.');
  }

  // Verify
  const expected = hashOTP(String(otp).trim());
  if (coupon.otp.hash !== expected) {
    await Coupon.findByIdAndUpdate(coupon._id, { $inc: { 'otp.attempts': 1 } });
    const left = 3 - (coupon.otp.attempts + 1);
    throw new Error(`Incorrect OTP. ${left} attempt(s) remaining.`);
  }

  // ── SUCCESS: decrypt code ──────────────────────────────────
  const realCode = decryptCoupon(coupon.encryptedCode);

  // Mark coupon sold
  await Coupon.findByIdAndUpdate(coupon._id, {
    status:       'sold',
    buyer:        buyerId,
    soldAt:       new Date(),
    'otp.hash':   null
  });

  // Release escrow
  txn.escrow.status     = 'released';
  txn.escrow.releasedAt = new Date();
  txn.status            = 'completed';
  txn.completedAt       = new Date();
  txn.notes.push({ msg: 'OTP verified. Escrow released to seller.' });
  await txn.save();

  // Credit seller wallet
  await User.findByIdAndUpdate(txn.seller, {
    $inc: { 'wallet.balance': txn.sellerPayout, totalTransactions: 1, successfulTransactions: 1 }
  });
  await User.findByIdAndUpdate(txn.buyer, {
    $inc: { totalTransactions: 1, successfulTransactions: 1 }
  });

  logger.info('Escrow released, coupon delivered', { txnId });

  return {
    success:   true,
    couponCode: realCode,      // ← First and only time the real code is returned
    brand:     coupon.brand,
    expiryDate: coupon.expiryDate,
    terms:     coupon.terms
  };
};

/* ─── Abort + Auto-Refund ──────────────────────────────────── */
const abortAndRefund = async (txnMongoId, reason) => {
  const txn = await Transaction.findById(txnMongoId);
  if (!txn) return;

  logger.warn('Escrow abort initiated', { txnId: txn.txnId, reason });

  // Release coupon back to active
  await Coupon.findByIdAndUpdate(txn.coupon, { status: 'active', buyer: null });

  // Trigger JusPay refund if payment was captured
  let refundResult = null;
  if (txn.payment.orderId && txn.payment.status === 'captured') {
    try {
      refundResult = await juspay.refund({
        orderId:  txn.payment.orderId,
        amount:   txn.amount,
        refundId: `REF-${txn.txnId}`,
        reason
      });
      txn.payment.refundId    = refundResult.refundId;
      txn.payment.refundedAt  = new Date();
      txn.payment.refundReason = reason;
      txn.payment.status      = 'refunded';
    } catch (refErr) {
      logger.error('Auto-refund failed — manual action required', { txnId: txn.txnId, err: refErr.message });
      txn.notes.push({ msg: `⚠️ MANUAL REFUND NEEDED: ${refErr.message}` });
    }
  }

  txn.escrow.status     = 'aborted';
  txn.escrow.abortedAt  = new Date();
  txn.escrow.abortReason = reason;
  txn.status            = 'refunded';
  txn.validation.status = 'failed';
  txn.validation.failReason = reason;
  txn.notes.push({ msg: `Aborted: ${reason}` });
  await txn.save();

  return { aborted: true, reason };
};

module.exports = { initiate, onPaymentSuccess, validate, verifyOTP, abortAndRefund };
