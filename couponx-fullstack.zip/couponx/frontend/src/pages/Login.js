import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

export default function Login() {
  const { login } = useAuth();
  const nav = useNavigate();
  const [form, setForm] = useState({ email: '', password: '' });
  const [err, setErr]   = useState('');
  const [busy, setBusy] = useState(false);

  const set = k => e => setForm(f => ({ ...f, [k]: e.target.value }));

  const submit = async e => {
    e.preventDefault();
    setErr(''); setBusy(true);
    try {
      const u = await login(form.email, form.password);
      toast.success(`Welcome back, ${u.name.split(' ')[0]}!`);
      nav(u.role === 'seller' ? '/dashboard' : '/marketplace');
    } catch (e) {
      setErr(e.response?.data?.message || 'Login failed. Check credentials.');
    } finally { setBusy(false); }
  };

  return (
    <div className="page" style={{ display:'flex',alignItems:'center',justifyContent:'center',padding:'2rem' }}>
      <div style={{ width:'100%',maxWidth:420 }}>
        <div style={{ textAlign:'center',marginBottom:'2rem' }}>
          <h1 style={{ fontSize:'2rem',marginBottom:'.4rem' }}>Welcome Back</h1>
          <p style={{ color:'var(--mut)' }}>Log in to your CouponX account</p>
        </div>

        {/* Demo creds */}
        <div style={{ background:'rgba(0,229,160,.07)',border:'1px solid rgba(0,229,160,.2)',
          borderRadius:12,padding:'1rem',marginBottom:'1.5rem',fontSize:'.8rem' }}>
          <div style={{ fontWeight:600,marginBottom:'.4rem',color:'var(--acc)' }}>🎭 Demo Credentials</div>
          <div style={{ color:'var(--mut)',lineHeight:1.8 }}>
            Buyer: <code style={{ color:'var(--txt)' }}>buyer@couponx.demo</code> / <code style={{ color:'var(--txt)' }}>Buyer@123</code><br/>
            Seller: <code style={{ color:'var(--txt)' }}>seller@couponx.demo</code> / <code style={{ color:'var(--txt)' }}>Seller@123</code>
          </div>
        </div>

        <form onSubmit={submit} className="card">
          {err && <div style={{ background:'rgba(239,68,68,.1)',border:'1px solid rgba(239,68,68,.25)',
            color:'var(--err)',padding:'.7rem 1rem',borderRadius:10,marginBottom:'1rem',fontSize:'.85rem' }}>{err}</div>}

          <div className="fg">
            <label className="fl">Email</label>
            <input className="fi" type="email" placeholder="you@example.com" value={form.email} onChange={set('email')} required/>
          </div>
          <div className="fg">
            <label className="fl">Password</label>
            <input className="fi" type="password" placeholder="••••••••" value={form.password} onChange={set('password')} required/>
          </div>

          <button className="btn btn-primary btn-full" type="submit" disabled={busy} style={{ marginTop:'.5rem' }}>
            {busy ? 'Signing in...' : 'Sign In →'}
          </button>

          <p style={{ textAlign:'center',marginTop:'1.2rem',fontSize:'.85rem',color:'var(--mut)' }}>
            No account? <Link to="/register" style={{ color:'var(--acc)' }}>Create one free</Link>
          </p>
        </form>
      </div>
    </div>
  );
}
