const Transaction = require('../models/Transaction');
const Coupon      = require('../models/Coupon');
const escrow      = require('../services/escrow');
const juspay      = require('../services/juspay');
const { verifyHmac } = require('../utils/encryption');
const logger      = require('../utils/logger');

/* POST /api/payments/initiate */
exports.initiate = async (req, res) => {
  try {
    const { couponId } = req.body;
    if (!couponId) return res.status(400).json({ success: false, message: 'couponId required.' });

    const result = await escrow.initiate({ couponId, buyerId: req.user._id });
    res.json({ success: true, data: result });
  } catch (err) {
    logger.error('Payment initiate error', { err: err.message });
    res.status(400).json({ success: false, message: err.message });
  }
};

/* POST /api/payments/webhook  — called by JusPay */
exports.webhook = async (req, res) => {
  try {
    // Body is raw buffer for signature verification
    const raw  = req.body.toString();
    const sig  = req.headers['x-jp-signature'] || '';
    const secret = process.env.JUSPAY_WEBHOOK_SECRET || '';

    if (secret && !verifyHmac(raw, sig, secret)) {
      logger.warn('Invalid JusPay webhook signature');
      return res.status(401).json({ success: false, message: 'Bad signature.' });
    }

    const payload = JSON.parse(raw);
    const { event_name, content } = payload;
    logger.info('JusPay webhook', { event: event_name, order: content?.order?.order_id });

    if (['ORDER_SUCCEEDED', 'PAYMENT_AUTHORIZED', 'TRANSACTION_CREATED'].includes(event_name)) {
      const order = content.order;
      if (juspay.mapStatus(order.status) === 'captured') {
        await escrow.onPaymentSuccess({ orderId: order.order_id, paymentId: order.txn_id, raw: order });
      }
    } else if (['ORDER_FAILED', 'PAYMENT_DECLINED'].includes(event_name)) {
      const order = content.order;
      const txn   = await Transaction.findOne({ 'payment.orderId': order.order_id });
      if (txn && txn.status === 'payment_pending') {
        await Coupon.findByIdAndUpdate(txn.coupon, { status: 'active' });
        txn.payment.status = 'failed';
        txn.status = 'failed';
        txn.notes.push({ msg: `Payment failed: ${order.error_message || 'Unknown'}` });
        await txn.save();
      }
    }

    res.json({ success: true }); // Always 200 to JusPay
  } catch (err) {
    logger.error('Webhook error', { err: err.message });
    res.json({ success: true }); // Still 200 to prevent retries
  }
};

/* POST /api/payments/verify-otp */
exports.verifyOTP = async (req, res) => {
  try {
    const { txnId, otp } = req.body;
    if (!txnId || !otp) return res.status(400).json({ success: false, message: 'txnId and otp required.' });

    const result = await escrow.verifyOTP({ txnId, buyerId: req.user._id, otp: String(otp).trim() });
    res.json({ success: true, data: result });
  } catch (err) {
    logger.error('OTP verify error', { err: err.message });
    res.status(400).json({ success: false, message: err.message });
  }
};

/* GET /api/payments/status/:txnId */
exports.status = async (req, res) => {
  try {
    const txn = await Transaction.findOne({ txnId: req.params.txnId, buyer: req.user._id })
      .populate('coupon', 'brand description maskedCode faceValue expiryDate category');
    if (!txn) return res.status(404).json({ success: false, message: 'Transaction not found.' });

    res.json({ success: true, data: {
      txnId:          txn.txnId,
      status:         txn.status,
      escrowStatus:   txn.escrow.status,
      validationStatus: txn.validation.status,
      amount:         txn.amount,
      paymentStatus:  txn.payment.status,
      coupon:         txn.coupon,
      completedAt:    txn.completedAt,
      createdAt:      txn.createdAt
    }});
  } catch {
    res.status(500).json({ success: false, message: 'Failed to fetch transaction.' });
  }
};

/* GET /api/payments/history */
exports.history = async (req, res) => {
  try {
    const docs = await Transaction.find({ buyer: req.user._id })
      .populate('coupon', 'brand description maskedCode category')
      .sort('-createdAt').limit(50);
    res.json({ success: true, data: docs });
  } catch {
    res.status(500).json({ success: false, message: 'Failed to fetch history.' });
  }
};

/* GET /api/payments/callback — JusPay redirect after payment */
exports.callback = (req, res) => {
  const { txn, order_id, status } = req.query;
  const fe = process.env.FRONTEND_URL || 'http://localhost:3000';
  const success = status === 'CHARGED';
  res.redirect(`${fe}/payment/${success ? 'processing' : 'failed'}?txn=${txn}&order=${order_id}`);
};
