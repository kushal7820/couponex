/**
 * Seed script — creates demo users and coupons
 * Usage: node src/utils/seed.js
 */
require('dotenv').config();
const mongoose = require('mongoose');
const User   = require('../models/User');
const Coupon = require('../models/Coupon');
const { encryptCoupon, maskCode } = require('./encryption');

const COUPONS = [
  { brand: 'Swiggy',      category: 'food',          description: '₹300 off on orders above ₹699', code: 'SWIG300SAVE', faceValue: 300,  salePrice: 129, minOrder: 699,  days: 30 },
  { brand: 'Zomato',      category: 'food',          description: '₹200 off, no minimum order',    code: 'ZOM200FREE',  faceValue: 200,  salePrice: 79,  minOrder: 0,    days: 25 },
  { brand: 'Amazon',      category: 'shopping',      description: '₹500 off on electronics',       code: 'AMZN500ELEC', faceValue: 500,  salePrice: 189, minOrder: 2999, days: 20 },
  { brand: 'Myntra',      category: 'shopping',      description: '₹700 off on fashion above ₹1999', code: 'MYNT700FSH', faceValue: 700,  salePrice: 249, minOrder: 1999, days: 15 },
  { brand: 'MakeMyTrip',  category: 'travel',        description: '₹1500 off on flights',          code: 'MMT1500FLY',  faceValue: 1500, salePrice: 599, minOrder: 5000, days: 10 },
  { brand: 'Ola',         category: 'travel',        description: '₹150 off on 3 rides',           code: 'OLA3RIDE150', faceValue: 150,  salePrice: 55,  minOrder: 0,    days: 6  },
  { brand: 'Cult.fit',    category: 'health',        description: '₹999 off 3-month membership',   code: 'CULT3MO999',  faceValue: 999,  salePrice: 349, minOrder: 0,    days: 45 },
  { brand: 'PharmEasy',   category: 'health',        description: '20% off on all medicines',      code: 'PHARMA20PCT', faceValue: 400,  salePrice: 129, minOrder: 499,  days: 22 },
  { brand: 'BookMyShow',  category: 'entertainment', description: '₹250 off on movie tickets',     code: 'BMS250MVIE',  faceValue: 250,  salePrice: 89,  minOrder: 0,    days: 18 },
  { brand: 'Flipkart',    category: 'shopping',      description: '₹600 off on appliances',        code: 'FK600APPL',   faceValue: 600,  salePrice: 219, minOrder: 3999, days: 12 },
];

const AI_SCORES = [88, 94, 72, 78, 65, 58, 82, 76, 85, 71];

async function seed() {
  await mongoose.connect(process.env.MONGODB_URI);
  console.log('Connected to MongoDB');

  // Clean
  await Promise.all([User.deleteMany({}), Coupon.deleteMany({})]);

  // Create users
  const seller = await User.create({ name: 'Demo Seller', email: 'seller@couponx.demo', password: 'Seller@123', role: 'seller', isVerified: true, trustScore: 95, totalTransactions: 42, successfulTransactions: 41 });
  const buyer  = await User.create({ name: 'Demo Buyer',  email: 'buyer@couponx.demo',  password: 'Buyer@123',  role: 'buyer',  isVerified: true, trustScore: 90 });
  const admin  = await User.create({ name: 'Admin',       email: 'admin@couponx.demo',  password: 'Admin@123',  role: 'admin',  isVerified: true });

  console.log('Users created: seller@couponx.demo / seller@couponx.demo / admin@couponx.demo (all pw: role@123 with capital first letter)');

  // Create coupons
  const expiry = (days) => new Date(Date.now() + days * 86400000);
  for (let i = 0; i < COUPONS.length; i++) {
    const c = COUPONS[i];
    const sc = AI_SCORES[i];
    await Coupon.create({
      seller:        seller._id,
      brand:         c.brand,
      category:      c.category,
      description:   c.description,
      encryptedCode: encryptCoupon(c.code),
      maskedCode:    maskCode(c.code),
      faceValue:     c.faceValue,
      salePrice:     c.salePrice,
      minOrder:      c.minOrder,
      expiryDate:    expiry(c.days),
      terms:         'Valid on app only. Cannot be combined with other offers.',
      status:        'active',
      ai: { score: sc, rating: sc >= 80 ? 'hot' : sc >= 60 ? 'good' : 'weak', fraudRisk: 'low', scoredAt: new Date() }
    });
  }

  console.log(`${COUPONS.length} coupons seeded`);
  console.log('\nDemo credentials:\n  Buyer:  buyer@couponx.demo  / Buyer@123\n  Seller: seller@couponx.demo / Seller@123\n  Admin:  admin@couponx.demo  / Admin@123');
  await mongoose.disconnect();
  process.exit(0);
}

seed().catch(err => { console.error(err); process.exit(1); });
