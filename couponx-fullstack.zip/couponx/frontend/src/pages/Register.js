import React, { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

export default function Register() {
  const { register } = useAuth();
  const nav = useNavigate();
  const [params] = useSearchParams();
  const [form, setForm] = useState({ name:'', email:'', password:'', phone:'', role: params.get('role') || 'buyer' });
  const [err,  setErr]  = useState('');
  const [busy, setBusy] = useState(false);

  const set = k => e => setForm(f => ({ ...f, [k]: e.target.value }));

  const submit = async e => {
    e.preventDefault(); setErr(''); setBusy(true);
    if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(form.password)) {
      setErr('Password must have uppercase, lowercase, and a number'); setBusy(false); return;
    }
    try {
      const u = await register(form);
      toast.success(`Account created! Welcome, ${u.name.split(' ')[0]}!`);
      nav(u.role === 'seller' ? '/sell' : '/marketplace');
    } catch (e) {
      setErr(e.response?.data?.message || e.response?.data?.errors?.[0]?.msg || 'Registration failed.');
    } finally { setBusy(false); }
  };

  return (
    <div className="page" style={{ display:'flex',alignItems:'center',justifyContent:'center',padding:'2rem' }}>
      <div style={{ width:'100%',maxWidth:460 }}>
        <div style={{ textAlign:'center',marginBottom:'2rem' }}>
          <h1 style={{ fontSize:'2rem',marginBottom:'.4rem' }}>Create Account</h1>
          <p style={{ color:'var(--mut)' }}>Join the smartest coupon marketplace</p>
        </div>

        <form onSubmit={submit} className="card">
          {err && <div style={{ background:'rgba(239,68,68,.1)',border:'1px solid rgba(239,68,68,.25)',
            color:'var(--err)',padding:'.7rem 1rem',borderRadius:10,marginBottom:'1rem',fontSize:'.85rem' }}>{err}</div>}

          {/* Role selector */}
          <div style={{ display:'flex',gap:'.6rem',marginBottom:'1.2rem' }}>
            {['buyer','seller'].map(r => (
              <button key={r} type="button"
                onClick={() => setForm(f => ({ ...f, role: r }))}
                className="btn"
                style={{ flex:1,justifyContent:'center',
                  background: form.role === r ? (r === 'buyer' ? 'var(--pur)' : 'var(--acc)') : 'transparent',
                  color: form.role === r ? (r === 'buyer' ? '#fff' : '#000') : 'var(--mut)',
                  border:`1px solid ${form.role === r ? 'transparent' : 'var(--bdr)'}` }}>
                {r === 'buyer' ? '🛒 I want to Buy' : '🏪 I want to Sell'}
              </button>
            ))}
          </div>

          <div className="f2">
            <div className="fg">
              <label className="fl">Full Name</label>
              <input className="fi" placeholder="Rahul Sharma" value={form.name} onChange={set('name')} required/>
            </div>
            <div className="fg">
              <label className="fl">Phone</label>
              <input className="fi" type="tel" placeholder="9876543210" value={form.phone} onChange={set('phone')}/>
            </div>
          </div>
          <div className="fg">
            <label className="fl">Email</label>
            <input className="fi" type="email" placeholder="you@example.com" value={form.email} onChange={set('email')} required/>
          </div>
          <div className="fg">
            <label className="fl">Password</label>
            <input className="fi" type="password" placeholder="Min 8 chars, upper + lower + number" value={form.password} onChange={set('password')} required minLength={8}/>
          </div>

          <button className="btn btn-primary btn-full" type="submit" disabled={busy} style={{ marginTop:'.5rem' }}>
            {busy ? 'Creating account...' : `Create ${form.role === 'seller' ? 'Seller' : 'Buyer'} Account →`}
          </button>

          <p style={{ textAlign:'center',marginTop:'1.2rem',fontSize:'.85rem',color:'var(--mut)' }}>
            Already have an account? <Link to="/login" style={{ color:'var(--acc)' }}>Sign in</Link>
          </p>
        </form>
      </div>
    </div>
  );
}
