const jwt  = require('jsonwebtoken');
const { validationResult } = require('express-validator');
const User = require('../models/User');
const logger = require('../utils/logger');

const sign = (id, secret, exp) => jwt.sign({ id }, secret, { expiresIn: exp });

const tokens = (userId) => ({
  accessToken:  sign(userId, process.env.JWT_SECRET,         process.env.JWT_EXPIRE || '7d'),
  refreshToken: sign(userId, process.env.JWT_REFRESH_SECRET, process.env.JWT_REFRESH_EXPIRE || '30d')
});

const respond = async (user, code, res) => {
  const { accessToken, refreshToken } = tokens(user._id);
  await User.findByIdAndUpdate(user._id, { refreshToken, lastLogin: new Date() });
  res.status(code).json({
    success: true, accessToken, refreshToken,
    user: { id: user._id, name: user.name, email: user.email, role: user.role, wallet: user.wallet, trustScore: user.trustScore }
  });
};

exports.register = async (req, res) => {
  const errs = validationResult(req);
  if (!errs.isEmpty()) return res.status(400).json({ success: false, errors: errs.array() });

  try {
    const { name, email, password, phone, role } = req.body;
    if (await User.findOne({ email }))
      return res.status(409).json({ success: false, message: 'Email already registered.' });

    const user = await User.create({ name, email, password, phone, role: ['buyer','seller'].includes(role) ? role : 'buyer' });
    logger.info('User registered', { email, role: user.role });
    respond(user, 201, res);
  } catch (err) {
    logger.error('Register error', { err: err.message });
    res.status(500).json({ success: false, message: 'Registration failed.' });
  }
};

exports.login = async (req, res) => {
  const errs = validationResult(req);
  if (!errs.isEmpty()) return res.status(400).json({ success: false, errors: errs.array() });

  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email }).select('+password');
    if (!user) return res.status(401).json({ success: false, message: 'Invalid credentials.' });
    if (user.isLocked()) return res.status(423).json({ success: false, message: 'Account locked. Try again later.' });

    const ok = await user.matchPassword(password);
    if (!ok) { await user.incAttempts(); return res.status(401).json({ success: false, message: 'Invalid credentials.' }); }
    if (!user.isActive) return res.status(403).json({ success: false, message: 'Account deactivated.' });

    if (user.loginAttempts) await User.findByIdAndUpdate(user._id, { $set: { loginAttempts: 0 }, $unset: { lockUntil: 1 } });
    logger.info('User logged in', { email });
    respond(user, 200, res);
  } catch (err) {
    logger.error('Login error', { err: err.message });
    res.status(500).json({ success: false, message: 'Login failed.' });
  }
};

exports.refresh = async (req, res) => {
  try {
    const { refreshToken } = req.body;
    if (!refreshToken) return res.status(401).json({ success: false, message: 'Refresh token required.' });

    const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);
    const user = await User.findById(decoded.id).select('+refreshToken');
    if (!user || user.refreshToken !== refreshToken)
      return res.status(401).json({ success: false, message: 'Invalid refresh token.' });

    const accessToken = sign(user._id, process.env.JWT_SECRET, process.env.JWT_EXPIRE || '7d');
    res.json({ success: true, accessToken });
  } catch {
    res.status(401).json({ success: false, message: 'Refresh token expired.' });
  }
};

exports.logout = async (req, res) => {
  await User.findByIdAndUpdate(req.user._id, { $unset: { refreshToken: 1 } });
  res.json({ success: true, message: 'Logged out.' });
};

exports.me = (req, res) => {
  res.json({ success: true, user: req.user });
};
