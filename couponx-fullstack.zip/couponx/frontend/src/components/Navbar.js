import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

export default function Navbar() {
  const { user, logout } = useAuth();
  const nav = useNavigate();
  const loc = useLocation();
  const [open, setOpen] = useState(false);
  const active = p => loc.pathname === p;

  const doLogout = async () => { await logout(); toast.success('Logged out'); nav('/'); };

  const links = [
    { to: '/marketplace', label: 'Marketplace' },
    ...(user?.role === 'seller' || user?.role === 'admin' ? [{ to: '/sell', label: 'Sell' }] : []),
    ...(user ? [{ to: '/dashboard', label: 'Dashboard' }] : [])
  ];

  return (
    <nav style={{ position:'fixed',top:0,left:0,right:0,zIndex:200,height:64,
      background:'rgba(8,12,20,.92)',backdropFilter:'blur(20px)',
      borderBottom:'1px solid var(--bdr)',display:'flex',alignItems:'center',
      padding:'0 1.5rem',justifyContent:'space-between',gap:'1rem' }}>

      <Link to="/" style={{ fontFamily:'Syne,sans-serif',fontWeight:800,fontSize:'1.35rem',
        background:'linear-gradient(135deg,#00e5a0,#00b4ff)',
        WebkitBackgroundClip:'text',WebkitTextFillColor:'transparent',whiteSpace:'nowrap' }}>
        CouponX
      </Link>

      {/* Desktop */}
      <div style={{ display:'flex',gap:'1.6rem',alignItems:'center',flexWrap:'nowrap' }}>
        {links.map(l => (
          <Link key={l.to} to={l.to} style={{
            color: active(l.to) ? 'var(--acc)' : 'var(--mut)',
            fontSize:'.88rem',fontWeight:500,transition:'color .2s',whiteSpace:'nowrap'
          }}>{l.label}</Link>
        ))}
        {user ? (
          <>
            <span style={{ fontSize:'.82rem',color:'var(--mut)',whiteSpace:'nowrap' }}>
              {user.role === 'seller' ? '🏪' : '🛒'} {user.name.split(' ')[0]}
            </span>
            <button className="btn btn-sm btn-secondary" onClick={doLogout}>Logout</button>
          </>
        ) : (
          <div style={{ display:'flex',gap:'.6rem' }}>
            <Link to="/login"    className="btn btn-sm btn-secondary">Login</Link>
            <Link to="/register" className="btn btn-sm btn-primary">Sign Up</Link>
          </div>
        )}
      </div>
    </nav>
  );
}
