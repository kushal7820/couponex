const { validationResult } = require('express-validator');
const Coupon = require('../models/Coupon');
const { encryptCoupon, maskCode } = require('../utils/encryption');
const { scoreCoupon } = require('../services/ai');
const logger = require('../utils/logger');

exports.list = async (req, res) => {
  try {
    const { category, sort = '-createdAt', page = 1, limit = 20, q } = req.query;
    const filter = { status: 'active', expiryDate: { $gt: new Date() } };
    if (category) filter.category = category;
    if (q) filter.$text = { $search: q };

    const skip = (Number(page) - 1) * Number(limit);
    const [docs, total] = await Promise.all([
      Coupon.find(filter)
        .select('-encryptedCode -otp')
        .populate('seller', 'name trustScore successfulTransactions')
        .sort(sort).skip(skip).limit(Number(limit)).lean(),
      Coupon.countDocuments(filter)
    ]);

    res.json({ success: true, data: docs, total, page: Number(page), pages: Math.ceil(total / Number(limit)) });
  } catch (err) {
    logger.error('Coupon list error', { err: err.message });
    res.status(500).json({ success: false, message: 'Failed to fetch coupons.' });
  }
};

exports.get = async (req, res) => {
  try {
    const doc = await Coupon.findById(req.params.id)
      .select('-encryptedCode -otp')
      .populate('seller', 'name trustScore totalTransactions');
    if (!doc) return res.status(404).json({ success: false, message: 'Coupon not found.' });
    await Coupon.findByIdAndUpdate(req.params.id, { $inc: { views: 1 } });
    res.json({ success: true, data: doc });
  } catch {
    res.status(500).json({ success: false, message: 'Failed to fetch coupon.' });
  }
};

exports.create = async (req, res) => {
  const errs = validationResult(req);
  if (!errs.isEmpty()) return res.status(400).json({ success: false, errors: errs.array() });

  try {
    const { brand, category, description, couponCode, faceValue, salePrice, minOrder, expiryDate, terms, applicableOn } = req.body;

    if (Number(salePrice) >= Number(faceValue))
      return res.status(400).json({ success: false, message: 'Sale price must be less than face value.' });

    const daysLeft = Math.ceil((new Date(expiryDate) - Date.now()) / 86400000);
    if (daysLeft < 3)
      return res.status(400).json({ success: false, message: 'Coupon must have at least 3 days until expiry.' });

    const encryptedCode = encryptCoupon(couponCode.trim());
    const maskedCode    = maskCode(couponCode.trim());

    const coupon = await Coupon.create({
      seller: req.user._id,
      brand, category, description, encryptedCode, maskedCode,
      faceValue: Number(faceValue), salePrice: Number(salePrice),
      minOrder: Number(minOrder) || 0, expiryDate: new Date(expiryDate),
      terms, applicableOn, status: 'pending_review'
    });

    // AI scoring in background
    scoreCoupon({ brand, category, description, faceValue, salePrice, minOrder, expiryDate })
      .then(ai => Coupon.findByIdAndUpdate(coupon._id, {
        'ai.score': ai.score, 'ai.rating': ai.rating,
        'ai.fraudRisk': ai.fraudRisk, 'ai.flags': ai.flags || [],
        'ai.scoredAt': new Date(),
        status: ai.fraudRisk === 'high' ? 'flagged' : 'active'
      }))
      .catch(err => {
        logger.warn('AI scoring failed for coupon', { id: coupon._id, err: err.message });
        Coupon.findByIdAndUpdate(coupon._id, { status: 'active', 'ai.rating': 'unrated' });
      });

    logger.info('Coupon listed', { id: coupon._id, brand, seller: req.user.email });
    res.status(201).json({
      success: true, message: 'Coupon listed! AI validation in progress.',
      data: { id: coupon._id, brand, maskedCode, salePrice: coupon.salePrice, status: coupon.status }
    });
  } catch (err) {
    logger.error('Coupon create error', { err: err.message });
    res.status(500).json({ success: false, message: 'Failed to list coupon.' });
  }
};

exports.myListings = async (req, res) => {
  try {
    const docs = await Coupon.find({ seller: req.user._id }).select('-encryptedCode -otp').sort('-createdAt');
    res.json({ success: true, data: docs });
  } catch {
    res.status(500).json({ success: false, message: 'Failed to fetch listings.' });
  }
};

exports.remove = async (req, res) => {
  try {
    const coupon = await Coupon.findById(req.params.id);
    if (!coupon) return res.status(404).json({ success: false, message: 'Not found.' });
    if (String(coupon.seller) !== String(req.user._id) && req.user.role !== 'admin')
      return res.status(403).json({ success: false, message: 'Not authorized.' });
    if (['sold','reserved'].includes(coupon.status))
      return res.status(400).json({ success: false, message: 'Cannot remove this coupon.' });
    await coupon.deleteOne();
    res.json({ success: true, message: 'Coupon removed.' });
  } catch {
    res.status(500).json({ success: false, message: 'Failed to remove coupon.' });
  }
};
