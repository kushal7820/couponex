import React, { useState, useEffect, useCallback } from 'react';
import { couponAPI, paymentAPI } from '../services/api';
import CouponCard from '../components/CouponCard';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';

const CATS = [
  { v:'', l:'All' },
  { v:'food', l:'🍕 Food' },
  { v:'shopping', l:'🛍 Shopping' },
  { v:'travel', l:'✈️ Travel' },
  { v:'health', l:'💊 Health' },
  { v:'entertainment', l:'🎬 Entertainment' },
];

export default function Marketplace() {
  const [coupons, setCoupons] = useState([]);
  const [loading, setLoading] = useState(true);
  const [cat, setCat]         = useState('');
  const [q, setQ]             = useState('');
  const [sort, setSort]       = useState('-createdAt');
  const [modal, setModal]     = useState(null);
  const [buying, setBuying]   = useState(false);
  const nav = useNavigate();

  const fetch = useCallback(async () => {
    setLoading(true);
    try {
      const r = await couponAPI.list({ category: cat || undefined, sort, q: q || undefined });
      setCoupons(r.data.data);
    } catch { toast.error('Failed to load coupons'); }
    finally { setLoading(false); }
  }, [cat, sort, q]);

  useEffect(() => { const t = setTimeout(fetch, 350); return () => clearTimeout(t); }, [fetch]);

  const confirmBuy = async () => {
    setBuying(true);
    try {
      const r = await paymentAPI.initiate(modal._id);
      const { txnId, paymentUrl } = r.data.data;
      toast.success('Payment session created!');
      // In prod open paymentUrl in same tab for JusPay hosted page
      // For demo we navigate directly to payment flow
      nav(`/payment/processing?txn=${txnId}`);
    } catch (e) {
      toast.error(e.response?.data?.message || 'Could not initiate payment');
    } finally { setBuying(false); setModal(null); }
  };

  return (
    <div className="page">
      <div className="container" style={{ paddingTop:'2rem', paddingBottom:'4rem' }}>
        {/* Header */}
        <div style={{ marginBottom:'2rem' }}>
          <div className="bdg bdg-g" style={{ marginBottom:'.6rem' }}>LIVE MARKETPLACE</div>
          <h1 style={{ fontSize:'clamp(1.8rem,4vw,2.8rem)', marginBottom:'.4rem' }}>Buy Verified Coupons</h1>
          <p style={{ color:'var(--mut)', fontSize:'.9rem' }}>AI-validated · Escrow-protected · Code hidden until OTP verified</p>
        </div>

        {/* Filters */}
        <div style={{ display:'flex', gap:'.75rem', flexWrap:'wrap', marginBottom:'1.5rem', alignItems:'center' }}>
          <input className="fi" style={{ width:220, flex:'none' }}
            placeholder="🔍 Search brand or description…"
            value={q} onChange={e => setQ(e.target.value)} />

          <div style={{ display:'flex', gap:'.45rem', flexWrap:'wrap' }}>
            {CATS.map(c => (
              <button key={c.v} className="btn btn-sm"
                onClick={() => setCat(c.v)}
                style={{
                  background: cat === c.v ? 'var(--pur)' : 'transparent',
                  color: cat === c.v ? '#fff' : 'var(--mut)',
                  border: `1px solid ${cat === c.v ? 'var(--pur)' : 'var(--bdr)'}`,
                }}>{c.l}</button>
            ))}
          </div>

          <select className="fs" style={{ width:170, flex:'none' }} value={sort} onChange={e => setSort(e.target.value)}>
            <option value="-createdAt">Newest First</option>
            <option value="salePrice">Price: Low → High</option>
            <option value="-salePrice">Price: High → Low</option>
            <option value="-ai.score">Best Deal First</option>
            <option value="expiryDate">Expiring Soon</option>
          </select>
        </div>

        {/* Grid */}
        {loading ? (
          <div className="g-auto">
            {[...Array(6)].map((_, i) => <div key={i} className="skel" style={{ height:360 }} />)}
          </div>
        ) : coupons.length === 0 ? (
          <div style={{ textAlign:'center', padding:'5rem', color:'var(--mut)' }}>
            <div style={{ fontSize:'3rem', marginBottom:'1rem' }}>🎫</div>
            <p>No coupons found. Try adjusting your filters.</p>
          </div>
        ) : (
          <div className="g-auto">
            {coupons.map(c => <CouponCard key={c._id} c={c} onBuy={setModal} />)}
          </div>
        )}
      </div>

      {/* Buy Modal */}
      {modal && (
        <div className="mo" onClick={e => e.target === e.currentTarget && setModal(null)}>
          <div className="md">
            <button className="mc" onClick={() => setModal(null)}>×</button>
            <div style={{ textAlign:'center', marginBottom:'1.4rem' }}>
              <div style={{ fontSize:'2.5rem', marginBottom:'.4rem' }}>🛒</div>
              <h3 style={{ fontSize:'1.3rem' }}>Confirm Purchase</h3>
            </div>

            <div style={{ background:'var(--sur2)', borderRadius:12, padding:'1rem', marginBottom:'1.2rem' }}>
              {[
                ['Brand',       modal.brand],
                ['Coupon Value', `₹${modal.faceValue}`],
                ['You Pay',      `₹${modal.salePrice}`],
                ['You Save',     `₹${modal.faceValue - modal.salePrice} (${modal.savingPct ?? Math.round(((modal.faceValue - modal.salePrice)/modal.faceValue)*100)}%)`],
              ].map(([k,v]) => (
                <div key={k} style={{ display:'flex', justifyContent:'space-between', marginBottom:'.5rem', fontSize:'.88rem' }}>
                  <span style={{ color:'var(--mut)' }}>{k}</span>
                  <strong style={{ color: k === 'You Pay' ? 'var(--acc)' : 'var(--txt)' }}>{v}</strong>
                </div>
              ))}
              <div className="divider" />
              <div style={{ fontSize:'.78rem', color:'var(--mut)', lineHeight:1.6 }}>
                🔒 Your payment is held in <strong>escrow</strong>. Coupon code revealed only after AI validation + your OTP. If validation fails, you are <strong>automatically refunded</strong>.
              </div>
            </div>

            <div style={{ display:'flex', gap:'.75rem' }}>
              <button className="btn btn-secondary" style={{ flex:1, justifyContent:'center' }} onClick={() => setModal(null)}>Cancel</button>
              <button className="btn btn-primary"   style={{ flex:1, justifyContent:'center' }} onClick={confirmBuy} disabled={buying}>
                {buying ? 'Processing…' : `🔒 Pay ₹${modal.salePrice}`}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
