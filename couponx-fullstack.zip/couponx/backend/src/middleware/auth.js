const jwt  = require('jsonwebtoken');
const User = require('../models/User');
const logger = require('../utils/logger');

const protect = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.startsWith('Bearer ')
      ? req.headers.authorization.split(' ')[1]
      : req.cookies?.jwt;

    if (!token) return res.status(401).json({ success: false, message: 'Not authenticated. Please log in.' });

    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (e) {
      if (e.name === 'TokenExpiredError')
        return res.status(401).json({ success: false, code: 'TOKEN_EXPIRED', message: 'Session expired. Please log in again.' });
      return res.status(401).json({ success: false, message: 'Invalid token.' });
    }

    const user = await User.findById(decoded.id);
    if (!user)          return res.status(401).json({ success: false, message: 'User no longer exists.' });
    if (!user.isActive) return res.status(403).json({ success: false, message: 'Account deactivated.' });
    if (user.isLocked()) return res.status(423).json({ success: false, message: 'Account temporarily locked.' });
    if (user.passwordChangedAfter(decoded.iat))
      return res.status(401).json({ success: false, message: 'Password changed. Please log in again.' });

    req.user = user;
    next();
  } catch (err) {
    logger.error('Auth middleware error', { err: err.message });
    res.status(500).json({ success: false, message: 'Authentication error.' });
  }
};

const restrictTo = (...roles) => (req, res, next) => {
  if (!roles.includes(req.user.role))
    return res.status(403).json({ success: false, message: 'You do not have permission for this action.' });
  next();
};

const optionalAuth = async (req, _, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    if (token) {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.user = await User.findById(decoded.id);
    }
  } catch {}
  next();
};

module.exports = { protect, restrictTo, optionalAuth };
