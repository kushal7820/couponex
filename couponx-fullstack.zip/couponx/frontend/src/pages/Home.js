import React from 'react';
import { Link } from 'react-router-dom';

const stats = [['₹4.2B','Lost Annually to Expiry'],['340M+','Coupons Wasted/Year'],['98%','Fraud Detection Rate'],['AES-256','Encryption Standard']];
const steps = [
  { icon:'📋', n:'01', t:'Seller Lists',    d:'Seller submits coupon. AI instantly validates and scores it. Fraudulent coupons are flagged before going live.' },
  { icon:'🔐', n:'02', t:'Code Encrypted',  d:'Coupon code encrypted with AES-256 immediately on submission. Even admins cannot read it without completing the escrow.' },
  { icon:'💰', n:'03', t:'Escrow Payment',  d:'Buyer pays via JusPay. Funds are held in escrow — no money moves until the full process completes.' },
  { icon:'✅', n:'04', t:'Coupon Validated', d:'AI + system validates the coupon is still live and unused. If validation fails, escrow is aborted and buyer auto-refunded.' },
  { icon:'📱', n:'05', t:'OTP Transfer',    d:'6-digit OTP sent to buyer. On correct entry, the real coupon code is decrypted and revealed — nowhere else.' },
  { icon:'⭐', n:'06', t:'Money Released',  d:'Seller receives payment. Both parties rate each other, building a transparent trust network.' },
];

export default function Home() {
  return (
    <div className="page" style={{ paddingTop:0 }}>
      {/* Hero */}
      <div style={{ minHeight:'100vh',display:'flex',flexDirection:'column',alignItems:'center',
        justifyContent:'center',textAlign:'center',padding:'7rem 1.5rem 4rem',position:'relative',overflow:'hidden' }}>
        <div style={{ position:'absolute',inset:0,pointerEvents:'none',
          background:'radial-gradient(ellipse 60% 50% at 50% 10%,rgba(0,229,160,.12) 0%,transparent 70%),' +
          'radial-gradient(ellipse 40% 40% at 80% 80%,rgba(124,58,237,.1) 0%,transparent 60%)' }}/>

        <div style={{ display:'inline-flex',alignItems:'center',gap:'.5rem',
          background:'rgba(0,229,160,.1)',border:'1px solid rgba(0,229,160,.25)',
          color:'var(--acc)',padding:'.3rem 1rem',borderRadius:100,fontSize:'.78rem',fontWeight:500,marginBottom:'1.4rem' }}>
          <span style={{ width:6,height:6,background:'var(--acc)',borderRadius:'50%',animation:'pulse 1.5s ease infinite' }}/>
          AI-Powered · Escrow-Protected · AES-256 Encrypted
        </div>

        <h1 style={{ fontSize:'clamp(2.6rem,7vw,5.2rem)',lineHeight:1.06,marginBottom:'1.1rem' }}>
          Turn Unused Coupons<br/>Into <span style={{ color:'var(--acc)' }}>Real Money</span>
        </h1>
        <p style={{ color:'var(--mut)',fontSize:'clamp(.95rem,2vw,1.15rem)',maxWidth:580,lineHeight:1.7,marginBottom:'2.5rem' }}>
          CouponX is a secured peer-to-peer coupon marketplace. Every code is encrypted at rest,
          payment is held in escrow, and the real coupon is only revealed after OTP verification.
        </p>

        <div style={{ display:'flex',gap:'1rem',flexWrap:'wrap',justifyContent:'center',marginBottom:'3rem' }}>
          <Link to="/marketplace" className="btn btn-primary" style={{ padding:'.85rem 2rem',fontSize:'1rem' }}>🛒 Browse Coupons</Link>
          <Link to="/register"    className="btn btn-secondary" style={{ padding:'.85rem 2rem',fontSize:'1rem' }}>💰 Start Selling</Link>
        </div>

        <div style={{ display:'flex',gap:'2.5rem',flexWrap:'wrap',justifyContent:'center' }}>
          {stats.map(([n,l])=>(
            <div key={l} style={{ textAlign:'center' }}>
              <div style={{ fontFamily:'Syne,sans-serif',fontSize:'1.9rem',fontWeight:800,color:'var(--acc)' }}>{n}</div>
              <div style={{ color:'var(--mut)',fontSize:'.75rem',marginTop:'.18rem' }}>{l}</div>
            </div>
          ))}
        </div>
      </div>

      {/* How it works */}
      <div style={{ padding:'5rem 1.5rem',maxWidth:1200,margin:'0 auto' }}>
        <div style={{ textAlign:'center',marginBottom:'3rem' }}>
          <div className="bdg bdg-g" style={{ marginBottom:'.75rem' }}>HOW IT WORKS</div>
          <h2 style={{ fontSize:'clamp(1.8rem,4vw,2.8rem)',marginBottom:'.8rem' }}>Verified. Safe. Smart.</h2>
          <p style={{ color:'var(--mut)',maxWidth:520,margin:'0 auto',lineHeight:1.7 }}>
            Every transaction goes through a 6-step escrow pipeline. No one gets scammed — period.
          </p>
        </div>
        <div style={{ display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(260px,1fr))',gap:'1.2rem' }}>
          {steps.map(s=>(
            <div key={s.n} className="card" style={{ position:'relative' }}
              onMouseEnter={e=>e.currentTarget.style.transform='translateY(-4px)'}
              onMouseLeave={e=>e.currentTarget.style.transform=''}>
              <div style={{ position:'absolute',top:'.9rem',right:'1.1rem',fontFamily:'Syne,sans-serif',
                fontSize:'2.5rem',fontWeight:800,color:'rgba(0,229,160,.12)' }}>{s.n}</div>
              <div style={{ fontSize:'1.6rem',marginBottom:'.9rem' }}>{s.icon}</div>
              <h3 style={{ fontSize:'1rem',marginBottom:'.45rem' }}>{s.t}</h3>
              <p style={{ color:'var(--mut)',fontSize:'.83rem',lineHeight:1.6 }}>{s.d}</p>
            </div>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div style={{ padding:'4rem 1.5rem',textAlign:'center' }}>
        <div className="card" style={{ maxWidth:560,margin:'0 auto',background:'linear-gradient(135deg,rgba(0,229,160,.07),rgba(124,58,237,.07))',borderColor:'rgba(0,229,160,.2)' }}>
          <h2 style={{ fontSize:'1.8rem',marginBottom:'.75rem' }}>Ready to Start?</h2>
          <p style={{ color:'var(--mut)',marginBottom:'1.8rem',lineHeight:1.6 }}>
            Join thousands of users buying and selling verified coupons safely.
          </p>
          <div style={{ display:'flex',gap:'1rem',justifyContent:'center',flexWrap:'wrap' }}>
            <Link to="/register?role=buyer"  className="btn btn-primary">Join as Buyer</Link>
            <Link to="/register?role=seller" className="btn btn-secondary">Join as Seller</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
