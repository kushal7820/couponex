import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

const col = s => s >= 80 ? '#00e5a0' : s >= 60 ? '#f59e0b' : '#ef4444';
const lbl = s => s >= 80 ? '🔥 Hot Deal' : s >= 60 ? '👍 Good Deal' : '⚠️ Weak';

export default function CouponCard({ c, onBuy }) {
  const { user } = useAuth();
  const nav = useNavigate();
  const score  = c.ai?.score ?? 70;
  const color  = col(score);
  const days   = c.daysLeft ?? Math.ceil((new Date(c.expiryDate) - Date.now()) / 86400000);
  const savPct = c.savingPct ?? Math.round(((c.faceValue - c.salePrice) / c.faceValue) * 100);
  const urgent = days <= 5;

  const buy = () => {
    if (!user) { toast.error('Please login to buy'); nav('/login'); return; }
    if (user.role === 'seller') { toast.error('Switch to a buyer account to purchase'); return; }
    onBuy(c);
  };

  return (
    <div className="card" style={{ padding:0,overflow:'hidden',cursor:'default' }}
      onMouseEnter={e=>e.currentTarget.style.transform='translateY(-4px)'}
      onMouseLeave={e=>e.currentTarget.style.transform=''}>

      {/* Header */}
      <div style={{ padding:'1.1rem 1.3rem',borderBottom:'1px dashed rgba(255,255,255,.08)',
        background:'linear-gradient(135deg,var(--sur2),var(--sur))',
        display:'flex',justifyContent:'space-between',alignItems:'flex-start' }}>
        <div>
          <div style={{ fontFamily:'Syne,sans-serif',fontWeight:700,fontSize:'1rem' }}>{c.brand}</div>
          <div style={{ fontSize:'.68rem',color:'var(--mut)',marginTop:'.18rem',textTransform:'uppercase',letterSpacing:'.06em' }}>{c.category}</div>
        </div>
        <div style={{ background:`linear-gradient(135deg,${color},${color}88)`,color:'#000',
          fontWeight:800,fontSize:'.75rem',padding:'.28rem .6rem',borderRadius:7,whiteSpace:'nowrap' }}>
          {score}/100
        </div>
      </div>

      {/* Body */}
      <div style={{ padding:'1.1rem 1.3rem' }}>
        <p style={{ fontSize:'.83rem',color:'var(--mut)',marginBottom:'.9rem',lineHeight:1.55 }}>{c.description}</p>

        {/* Masked code */}
        <div style={{ fontFamily:'monospace',fontSize:'.95rem',fontWeight:700,
          background:'rgba(255,255,255,.04)',padding:'.45rem .8rem',
          borderRadius:8,border:'1px solid var(--bdr)',
          display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:'.85rem' }}>
          <span style={{ letterSpacing:'.08em' }}>{c.maskedCode}</span>
          <span style={{ fontSize:'.65rem',color:'var(--mut)' }}>🔒 Hidden</span>
        </div>

        {/* Deal bar */}
        <div style={{ marginBottom:'.85rem' }}>
          <div style={{ display:'flex',justifyContent:'space-between',marginBottom:'.28rem' }}>
            <span style={{ fontSize:'.7rem',color:'var(--mut)' }}>Deal Score</span>
            <span style={{ fontSize:'.7rem',fontWeight:700,color }}>{lbl(score)}</span>
          </div>
          <div className="db"><div className="df" style={{ width:`${score}%`,background:`linear-gradient(90deg,${color},${color}66)` }}/></div>
        </div>

        {/* Meta */}
        <div style={{ display:'flex',justifyContent:'space-between',fontSize:'.78rem',color:'var(--mut)',marginBottom:'.9rem' }}>
          <span>Min: {c.minOrder > 0 ? `₹${c.minOrder}` : 'None'}</span>
          <span style={{ color: urgent ? 'var(--err)' : 'var(--amb)', fontWeight:500, animation: urgent ? 'blink 1.4s ease infinite' : 'none' }}>
            ⏱ {days}d left
          </span>
        </div>

        {/* Price row */}
        <div style={{ display:'flex',justifyContent:'space-between',alignItems:'center' }}>
          <div>
            <div style={{ fontSize:'.75rem',color:'var(--mut)',textDecoration:'line-through' }}>₹{c.faceValue} value</div>
            <div style={{ fontFamily:'Syne,sans-serif',fontSize:'1.25rem',fontWeight:800,color:'var(--acc)' }}>
              ₹{c.salePrice} <span style={{ fontSize:'.68rem',color }}>{savPct}% off</span>
            </div>
          </div>
          <button className="btn btn-purple btn-sm" onClick={buy}>Buy Now →</button>
        </div>

        {/* Seller */}
        {c.seller && (
          <div style={{ marginTop:'.8rem',paddingTop:'.8rem',borderTop:'1px solid var(--bdr)',
            display:'flex',justifyContent:'space-between',fontSize:'.7rem',color:'var(--mut)' }}>
            <span>by {c.seller.name}</span>
            <span style={{ color:'var(--acc)' }}>⭐ {c.seller.trustScore}/100</span>
          </div>
        )}
      </div>
    </div>
  );
}
