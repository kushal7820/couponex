const mongoose = require('mongoose');

const couponSchema = new mongoose.Schema({
  seller:      { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  buyer:       { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },

  brand:       { type: String, required: true, trim: true, maxlength: 100 },
  category:    { type: String, required: true, enum: ['food','shopping','travel','health','entertainment','other'] },
  description: { type: String, required: true, maxlength: 500 },

  // AES-256 encrypted — NEVER returned in API responses until escrow released
  encryptedCode: { type: String, required: true, select: false },
  // Shown to buyers before purchase (e.g. "SAV*****")
  maskedCode:    { type: String, required: true },

  faceValue:    { type: Number, required: true, min: 1 },
  salePrice:    { type: Number, required: true, min: 1 },
  minOrder:     { type: Number, default: 0 },
  expiryDate:   { type: Date, required: true },
  terms:        { type: String, maxlength: 1000, default: '' },
  applicableOn: { type: String, maxlength: 200, default: '' },

  status: {
    type: String,
    enum: ['pending_review', 'active', 'reserved', 'sold', 'expired', 'flagged', 'removed'],
    default: 'pending_review'
  },

  // AI scoring
  ai: {
    score:      { type: Number, min: 0, max: 100, default: null },
    rating:     { type: String, enum: ['hot','good','weak','unrated'], default: 'unrated' },
    fraudRisk:  { type: String, enum: ['low','medium','high'], default: 'low' },
    flags:      [String],
    scoredAt:   Date
  },

  // OTP for transfer — stored hashed, selected explicitly
  otp: {
    hash:      { type: String, select: false },
    expiresAt: { type: Date },
    attempts:  { type: Number, default: 0 }
  },

  views:       { type: Number, default: 0 },
  soldAt:      { type: Date }
}, { timestamps: true });

couponSchema.virtual('daysLeft').get(function () {
  return Math.ceil((this.expiryDate - Date.now()) / 86400000);
});
couponSchema.virtual('savingPct').get(function () {
  return Math.round(((this.faceValue - this.salePrice) / this.faceValue) * 100);
});

couponSchema.set('toJSON', { virtuals: true });
couponSchema.set('toObject', { virtuals: true });

couponSchema.index({ status: 1, category: 1 });
couponSchema.index({ seller: 1 });
couponSchema.index({ expiryDate: 1 });
couponSchema.index({ brand: 'text', description: 'text' });

module.exports = mongoose.model('Coupon', couponSchema);
